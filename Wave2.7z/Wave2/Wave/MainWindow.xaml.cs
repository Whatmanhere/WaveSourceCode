﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CefSharp;
using CefSharp.Wpf;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SynapseXtra;
using Wave.Classes.Cosmetic;
using Wave.Classes.Implementations;
using Wave.Classes.Passive;
using Wave.Classes.WebSockets;
using Wave.Controls;
using Wave.Controls.AI;
using Wave.Controls.Settings;

namespace Wave
{
	// Token: 0x02000006 RID: 6
	public partial class MainWindow : Window
	{
		// Token: 0x06000017 RID: 23 RVA: 0x00002380 File Offset: 0x00000580
		private void DoNotification()
		{
			this.isNotifying = true;
			KeyValuePair<string, int> keyValuePair = this.notifications.First<KeyValuePair<string, int>>();
			this.notifications.Remove(keyValuePair.Key);
			this.NotificationContent.Text = keyValuePair.Key;
			this.DurationIndicator.Width = 0.0;
			this.currentNotification = Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.NotificationBorder)
				{
					Property = FrameworkElement.WidthProperty,
					To = 280
				},
				new AnimationPropertyBase(this.DurationIndicator)
				{
					Property = FrameworkElement.WidthProperty,
					To = 278,
					Duration = new Duration(TimeSpan.FromMilliseconds((double)keyValuePair.Value)),
					DisableEasing = true
				}
			});
			this.currentNotification.Completed += delegate(object sender, EventArgs e)
			{
				this.CloseNotification();
			};
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002474 File Offset: 0x00000674
		private void CloseNotification()
		{
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.NotificationBorder)
				{
					Property = FrameworkElement.WidthProperty,
					To = 0
				},
				new AnimationPropertyBase(this.DurationIndicator)
				{
					Property = FrameworkElement.WidthProperty,
					To = 0
				}
			}).Completed += async delegate(object sender2, EventArgs e2)
			{
				if (this.notifications.Count > 0)
				{
					await Task.Delay(250);
					this.DoNotification();
				}
				else
				{
					this.isNotifying = false;
				}
			};
		}

		// Token: 0x06000019 RID: 25 RVA: 0x000024E7 File Offset: 0x000006E7
		private void PopupNotification(string message, int duration = 2500)
		{
			this.notifications.Add(message, duration);
			if (this.isNotifying)
			{
				return;
			}
			Application.Current.Dispatcher.Invoke(delegate
			{
				this.DoNotification();
			});
		}

		// Token: 0x0600001A RID: 26 RVA: 0x0000251C File Offset: 0x0000071C
		private void NewTab(string tabName = "x", string content = "print('Hello World!');", bool autoSave = true)
		{
			MainWindow.<>c__DisplayClass21_0 CS$<>8__locals1 = new MainWindow.<>c__DisplayClass21_0();
			CS$<>8__locals1.content = content;
			CS$<>8__locals1.autoSave = autoSave;
			CS$<>8__locals1.<>4__this = this;
			if (tabName == "x")
			{
				this.tabReferences++;
				tabName = "Tab " + this.tabReferences.ToString() + ".lua";
			}
			TabItem tabItem = new TabItem
			{
				BorderThickness = new Thickness(0.0),
				FontFamily = new FontFamily("SF Pro"),
				FontSize = 14.0,
				Foreground = new SolidColorBrush(Colors.Gainsboro),
				Header = tabName,
				Height = 40.0,
				Margin = new Thickness(-2.0, -2.0, -2.0, 0.0)
			};
			CS$<>8__locals1.newBrowser = new ChromiumWebBrowser
			{
				BorderThickness = new Thickness(0.0)
			};
			CS$<>8__locals1.newBrowser.FrameLoadEnd += delegate(object sender, FrameLoadEndEventArgs e)
			{
				MainWindow.<>c__DisplayClass21_0.<<NewTab>b__0>d <<NewTab>b__0>d;
				<<NewTab>b__0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<NewTab>b__0>d.<>4__this = CS$<>8__locals1;
				<<NewTab>b__0>d.<>1__state = -1;
				<<NewTab>b__0>d.<>t__builder.Start<MainWindow.<>c__DisplayClass21_0.<<NewTab>b__0>d>(ref <<NewTab>b__0>d);
			};
			tabItem.Content = CS$<>8__locals1.newBrowser;
			CS$<>8__locals1.newBrowser.Load("http://localhost:1111");
			tabItem.IsSelected = true;
			this.ScriptTabs.Items.Add(tabItem);
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00002674 File Offset: 0x00000874
		private void RemoveTab(string tabName)
		{
			if (this.ScriptTabs.Items.Count <= 1)
			{
				return;
			}
			foreach (object obj in ((IEnumerable)this.ScriptTabs.Items))
			{
				TabItem tabItem = (TabItem)obj;
				if ((string)tabItem.Header == tabName)
				{
					this.ScriptTabs.Items.Remove(tabItem);
					break;
				}
			}
			string text = "data/tabs/" + tabName;
			if (File.Exists(text))
			{
				File.Delete(text);
			}
			((TabItem)this.ScriptTabs.Items[0]).IsSelected = true;
		}

		// Token: 0x0600001C RID: 28 RVA: 0x0000273C File Offset: 0x0000093C
		private async void AutoSaveTabs()
		{
			string[] files = Directory.GetFiles("data/tabs");
			for (int i = 0; i < files.Length; i++)
			{
				File.Delete(files[i]);
			}
			TabItem[] array = this.ScriptTabs.Items.Cast<TabItem>().ToArray<TabItem>();
			foreach (TabItem tabItem in array)
			{
				ChromiumWebBrowser chromiumWebBrowser = (ChromiumWebBrowser)tabItem.Content;
				if (chromiumWebBrowser.CanExecuteJavascriptInMainFrame)
				{
					object result = (await chromiumWebBrowser.EvaluateScriptAsync("window.getText();", null, false)).Result;
					if (result != null)
					{
						string currentDirectory = Environment.CurrentDirectory;
						string text = "/data/tabs/";
						object header = tabItem.Header;
						File.WriteAllText(currentDirectory + text + ((header != null) ? header.ToString() : null), result.ToString());
					}
				}
				tabItem = null;
			}
			TabItem[] array2 = null;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00002774 File Offset: 0x00000974
		private async void SendAIMessage(string message)
		{
			this.PopupNotification("This is just a preview, AI is disabled for now ;)", 4000);
			return;
			TaskAwaiter<JavascriptResponse> taskAwaiter2;
			TaskAwaiter<JavascriptResponse> taskAwaiter = taskAwaiter2;
			taskAwaiter2 = default(TaskAwaiter<JavascriptResponse>);
			string text = taskAwaiter.GetResult().Result.ToString();
			AIChat aichat;
			string text3;
			string text2 = await aichat.SendNewMessage(text3, text);
			MatchCollection matchCollection = Regex.Matches(text2, "```lua\\s*([^`]+)\\s*```", RegexOptions.Singleline);
			if (matchCollection.Count <= 0)
			{
				goto IL_176;
			}
			foreach (object obj in matchCollection)
			{
				Match match = (Match)obj;
				this.aiReferences++;
				string text4 = "AI Reference " + this.aiReferences.ToString() + ".lua";
				text2 = text2.Replace(match.Value, "Refer to tab: " + text4);
				this.NewTab(text4, match.Groups[1].Value, true);
			}
			IL_176:
			this.AIChatPanel.Children.Add(new AIBotMessage
			{
				Message = text2
			});
		}

		// Token: 0x0600001E RID: 30 RVA: 0x000027B3 File Offset: 0x000009B3
		private string GetApiLink(string query, int page)
		{
			if (query == "")
			{
				return "https://scriptblox.com/api/script/fetch?page=" + page.ToString();
			}
			return "https://scriptblox.com/api/script/search?filters=free&page=" + page.ToString() + "&q=" + query;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x000027EB File Offset: 0x000009EB
		private void SetCurrentPage(int page)
		{
			this.currentPage = page;
			this.CurrentPageLabel.Content = "Page " + page.ToString() + "/" + this.totalPages.ToString();
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00002820 File Offset: 0x00000A20
		private async void SearchScripts(string query = "", int page = 1)
		{
			if (!this.isSearching)
			{
				this.isSearching = true;
				this.lastQuery = query;
				try
				{
					this.SearchResultPanel.Children.Clear();
					using (HttpClient client = new HttpClient())
					{
						JToken jtoken = JToken.Parse(await (await client.GetAsync(this.GetApiLink(query, page))).Content.ReadAsStringAsync())["result"];
						ScriptObject[] array = JsonConvert.DeserializeObject<ScriptObject[]>(jtoken["scripts"].ToString());
						for (int i = 0; i < array.Length; i++)
						{
							MainWindow.<>c__DisplayClass27_0 CS$<>8__locals1 = new MainWindow.<>c__DisplayClass27_0();
							CS$<>8__locals1.<>4__this = this;
							CS$<>8__locals1.scriptObject = array[i];
							ScriptResult scriptResult = new ScriptResult(CS$<>8__locals1.scriptObject);
							((Button)scriptResult.FindName("ExecuteButton")).Click += delegate(object sender, RoutedEventArgs e)
							{
								MainWindow.<>c__DisplayClass27_0.<<SearchScripts>b__0>d <<SearchScripts>b__0>d;
								<<SearchScripts>b__0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
								<<SearchScripts>b__0>d.<>4__this = CS$<>8__locals1;
								<<SearchScripts>b__0>d.<>1__state = -1;
								<<SearchScripts>b__0>d.<>t__builder.Start<MainWindow.<>c__DisplayClass27_0.<<SearchScripts>b__0>d>(ref <<SearchScripts>b__0>d);
							};
							this.SearchResultPanel.Children.Add(scriptResult);
						}
						this.totalPages = Math.Max((int)jtoken["totalPages"], 1);
					}
					HttpClient client = null;
					this.SetCurrentPage(page);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
				finally
				{
					this.isSearching = false;
				}
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002868 File Offset: 0x00000A68
		private void ShowAdPane()
		{
			if (this.AdBorder.Visibility == Visibility.Collapsed)
			{
				this.MainBorder.Margin = new Thickness(4.0, 4.0, 4.0, 124.0);
				base.Height += 120.0;
				this.AdBorder.Visibility = Visibility.Visible;
			}
			base.MinHeight = 570.0;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x000028E8 File Offset: 0x00000AE8
		private void HideAdPane()
		{
			base.MinHeight = 450.0;
			if (this.AdBorder.Visibility == Visibility.Visible)
			{
				this.AdBorder.Visibility = Visibility.Collapsed;
				this.MainBorder.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
				base.Height -= 120.0;
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00002968 File Offset: 0x00000B68
		private void LoadAd()
		{
			this.currentAdvertisement = Advertisements.GetAdvertisement();
			this.AdBorder.Background = new ImageBrush
			{
				ImageSource = new BitmapImage(new Uri("pack://application:,,,/Wave;component" + this.currentAdvertisement.localImageLink, UriKind.Absolute))
			};
			this.ShowAdPane();
		}

		// Token: 0x06000024 RID: 36 RVA: 0x000029BC File Offset: 0x00000BBC
		private void InitializeAds()
		{
			this.LoadAd();
			Timer timer = new Timer(300000.0);
			timer.Elapsed += delegate(object sender, ElapsedEventArgs e)
			{
				Application.Current.Dispatcher.Invoke(delegate
				{
					this.LoadAd();
				});
			};
			timer.Start();
		}

		// Token: 0x06000025 RID: 37 RVA: 0x000029EC File Offset: 0x00000BEC
		private Storyboard AnimatePopupIn(Grid popupGrid)
		{
			popupGrid.Opacity = 0.0;
			popupGrid.Visibility = Visibility.Visible;
			Storyboard storyboard = Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(popupGrid)
				{
					Property = UIElement.OpacityProperty,
					To = 1
				}
			});
			this.MainBlur.BeginAnimation(BlurEffect.RadiusProperty, new DoubleAnimation
			{
				To = new double?((double)8),
				Duration = TimeSpan.FromSeconds(0.35)
			});
			return storyboard;
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00002A78 File Offset: 0x00000C78
		private Storyboard AnimatePopupOut(Grid popupGrid)
		{
			Storyboard storyboard = Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(popupGrid)
				{
					Property = UIElement.OpacityProperty,
					To = 0
				}
			});
			this.MainBlur.BeginAnimation(BlurEffect.RadiusProperty, new DoubleAnimation
			{
				To = new double?(0.0),
				Duration = TimeSpan.FromSeconds(0.35)
			});
			storyboard.Completed += delegate(object sender, EventArgs e)
			{
				popupGrid.Visibility = Visibility.Collapsed;
			};
			return storyboard;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00002B18 File Offset: 0x00000D18
		private async void InitiateLogin()
		{
			TaskAwaiter<bool> taskAwaiter = this.ValidateLogin().GetAwaiter();
			if (!taskAwaiter.IsCompleted)
			{
				await taskAwaiter;
				TaskAwaiter<bool> taskAwaiter2;
				taskAwaiter = taskAwaiter2;
				taskAwaiter2 = default(TaskAwaiter<bool>);
			}
			if (taskAwaiter.GetResult())
			{
				this.TransferToUI();
			}
			else
			{
				this.AnimatePopupIn(this.LoginPopupGrid);
			}
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00002B50 File Offset: 0x00000D50
		private async Task<bool> ValidateLogin()
		{
			return true;
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00002B8C File Offset: 0x00000D8C
		private void TransferToUI()
		{
			MainWindow.<>c__DisplayClass36_0 CS$<>8__locals1 = new MainWindow.<>c__DisplayClass36_0();
			CS$<>8__locals1.<>4__this = this;
			this.LoginPopupGrid.Visibility = Visibility.Collapsed;
			WebSocketCollection.AddSocket("clientInformation", 6001).AddBehaviour<ClientInformationBehavior>("/transferClientInformation");
			foreach (KeyValuePair<string, WebSocket> keyValuePair in WebSocketCollection.Sockets)
			{
				keyValuePair.Value.Server.Start();
			}
			Roblox.OnProcessFound += delegate(object sender2, RobloxInstanceEventArgs e2)
			{
				if (!e2.AlreadyOpen)
				{
					CS$<>8__locals1.<>4__this.PopupNotification("Attaching...", 2500);
				}
			};
			Roblox.OnProcessAdded += delegate(object sender2, RobloxInstanceEventArgs e2)
			{
				MainWindow.<>c__DisplayClass36_1 CS$<>8__locals2 = new MainWindow.<>c__DisplayClass36_1();
				CS$<>8__locals2.CS$<>8__locals1 = CS$<>8__locals1;
				CS$<>8__locals2.e2 = e2;
				if (!CS$<>8__locals2.e2.AlreadyOpen)
				{
					CS$<>8__locals1.<>4__this.PopupNotification("Attached!", 2500);
				}
				Application.Current.Dispatcher.Invoke<Task>(delegate
				{
					MainWindow.<>c__DisplayClass36_1.<<TransferToUI>b__6>d <<TransferToUI>b__6>d;
					<<TransferToUI>b__6>d.<>t__builder = AsyncTaskMethodBuilder.Create();
					<<TransferToUI>b__6>d.<>4__this = CS$<>8__locals2;
					<<TransferToUI>b__6>d.<>1__state = -1;
					<<TransferToUI>b__6>d.<>t__builder.Start<MainWindow.<>c__DisplayClass36_1.<<TransferToUI>b__6>d>(ref <<TransferToUI>b__6>d);
					return <<TransferToUI>b__6>d.<>t__builder.Task;
				});
			};
			Roblox.OnProcessRemoved += delegate(object sender2, RobloxInstanceEventArgs e2)
			{
				foreach (object obj in CS$<>8__locals1.<>4__this.InstanceStack.Children)
				{
					InstancePanel instancePanel = (InstancePanel)obj;
					if (instancePanel.ProcessID == e2.Id)
					{
						CS$<>8__locals1.<>4__this.InstanceStack.Children.Remove(instancePanel);
						break;
					}
				}
				if (CS$<>8__locals1.<>4__this.InstanceStack.Children.Count == 0)
				{
					CS$<>8__locals1.<>4__this.UpdateSelectedProcessID(null, null);
					return;
				}
				int? num3 = CS$<>8__locals1.<>4__this.selectedProcessId;
				int id = e2.Id;
				if ((num3.GetValueOrDefault() == id) & (num3 != null))
				{
					CS$<>8__locals1.<>4__this.UpdateSelectedProcessID(new int?(((InstancePanel)CS$<>8__locals1.<>4__this.InstanceStack.Children[0]).ProcessID), ((InstancePanel)CS$<>8__locals1.<>4__this.InstanceStack.Children[0]).Username);
				}
			};
			Roblox.OnProcessInformationGained += delegate(object sender2, DetailedRobloxInstanceEventArgs e2)
			{
				Application.Current.Dispatcher.Invoke(delegate
				{
					foreach (object obj2 in CS$<>8__locals1.<>4__this.InstanceStack.Children)
					{
						InstancePanel instancePanel2 = (InstancePanel)obj2;
						if (instancePanel2.ProcessID == e2.ProcessId)
						{
							instancePanel2.Username = e2.Username;
							instancePanel2.UserID = e2.UserId;
						}
					}
				});
			};
			Roblox.Start();
			this.MultiInstance.IsChecked = Settings.Instance.MultiInstance;
			this.AutoExecute.IsChecked = Settings.Instance.AutoExecute;
			this.SaveTabs.IsChecked = Settings.Instance.SaveTabs;
			this.TopMost.IsChecked = Settings.Instance.TopMost;
			this.EditorRefreshRate.Value = (double)Settings.Instance.EditorRefreshRate;
			this.EditorTextSize.Value = Settings.Instance.EditorTextSize;
			this.ShowMinimap.IsChecked = Settings.Instance.ShowMinimap;
			this.ShowInlayHints.IsChecked = Settings.Instance.ShowInlayHints;
			this.UseConversationHistory.IsChecked = Settings.Instance.UseConversationHistory;
			this.AppendCurrentScript.IsChecked = Settings.Instance.AppendCurrentScript;
			this.saveTabTimer.Elapsed += delegate(object sender2, ElapsedEventArgs e2)
			{
				if (Settings.Instance.SaveTabs)
				{
					Application.Current.Dispatcher.Invoke(delegate
					{
						CS$<>8__locals1.<>4__this.AutoSaveTabs();
					});
				}
			};
			CS$<>8__locals1.allowedExtensions = new string[] { ".lua", ".luau", ".txt" };
			string[] array = (from s in Directory.GetFiles("data/tabs")
				where CS$<>8__locals1.allowedExtensions.Contains(global::System.IO.Path.GetExtension(s).ToLowerInvariant())
				select s).ToArray<string>();
			if (array.Length != 0)
			{
				foreach (string text in array)
				{
					string fileName = global::System.IO.Path.GetFileName(text);
					Match match = Regex.Match(fileName, "Tab (\\d+).lua");
					if (match.Success)
					{
						int num = int.Parse(match.Groups[1].Value);
						if (num > this.tabReferences)
						{
							this.tabReferences = num;
						}
					}
					Match match2 = Regex.Match(fileName, "AI Reference (\\d+).lua");
					if (match2.Success)
					{
						int num2 = int.Parse(match2.Groups[1].Value);
						if (num2 > this.aiReferences)
						{
							this.aiReferences = num2;
						}
					}
					this.NewTab(fileName, File.ReadAllText(text), false);
				}
			}
			else
			{
				this.NewTab("x", "print('Hello World!');", true);
			}
			this.InitializeAds();
			this.SearchScripts("", 1);
			base.Topmost = this.TopMost.IsChecked;
			this.isTransferredToUI = true;
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00002E98 File Offset: 0x00001098
		public override void OnApplyTemplate()
		{
			HwndSource.FromHwnd(new WindowInteropHelper(this).Handle).AddHook(new HwndSourceHook(MainWindow.WindowProc));
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002EBB File Offset: 0x000010BB
		private static IntPtr WindowProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == 36)
			{
				MainWindow.WmGetMinMaxInfo(hwnd, lParam);
				handled = false;
			}
			return (IntPtr)0;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00002ED4 File Offset: 0x000010D4
		private static void WmGetMinMaxInfo(IntPtr hwnd, IntPtr lParam)
		{
			MainWindow.MINMAXINFO minmaxinfo = (MainWindow.MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(MainWindow.MINMAXINFO));
			int num = 2;
			IntPtr intPtr = MainWindow.MonitorFromWindow(hwnd, num);
			if (intPtr != IntPtr.Zero)
			{
				MainWindow.MONITORINFO monitorinfo = new MainWindow.MONITORINFO();
				MainWindow.GetMonitorInfo(intPtr, monitorinfo);
				MainWindow.RECT rcWork = monitorinfo.rcWork;
				MainWindow.RECT rcMonitor = monitorinfo.rcMonitor;
				minmaxinfo.ptMaxPosition.x = Math.Abs(rcWork.left - rcMonitor.left);
				minmaxinfo.ptMaxPosition.y = Math.Abs(rcWork.top - rcMonitor.top);
				minmaxinfo.ptMaxSize.x = Math.Abs(rcWork.right - rcWork.left);
				minmaxinfo.ptMaxSize.y = Math.Abs(rcWork.bottom - rcWork.top);
			}
			Marshal.StructureToPtr<MainWindow.MINMAXINFO>(minmaxinfo, lParam, true);
		}

		// Token: 0x0600002D RID: 45
		[DllImport("user32")]
		internal static extern bool GetMonitorInfo(IntPtr hMonitor, MainWindow.MONITORINFO lpmi);

		// Token: 0x0600002E RID: 46
		[DllImport("user32.dll")]
		private static extern bool GetCursorPos(ref Point lpPoint);

		// Token: 0x0600002F RID: 47
		[DllImport("User32")]
		internal static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);

		// Token: 0x06000030 RID: 48 RVA: 0x00002FB7 File Offset: 0x000011B7
		private void UpdateSelectedProcessID(int? id, string username)
		{
			this.selectedProcessId = id;
			this.SelectedProcessButton.Content = username;
			this.SelectedProcessButton.Visibility = ((id == null) ? Visibility.Collapsed : Visibility.Visible);
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00002FE4 File Offset: 0x000011E4
		public MainWindow()
		{
			MainWindow.<>c__DisplayClass48_0 CS$<>8__locals1 = new MainWindow.<>c__DisplayClass48_0();
			base..ctor();
			CS$<>8__locals1.<>4__this = this;
			this.InitializeComponent();
			this.previousWindowState = base.WindowState;
			this.InstancePopupGrid.Visibility = Visibility.Collapsed;
			this.SelectedProcessButton.Visibility = Visibility.Collapsed;
			CS$<>8__locals1.tabCheckBoxes = new KeyValuePair<TabCheckBox, Grid>[]
			{
				new KeyValuePair<TabCheckBox, Grid>(this.HomeButton, this.HomeTab),
				new KeyValuePair<TabCheckBox, Grid>(this.EditorButton, this.EditorTab),
				new KeyValuePair<TabCheckBox, Grid>(this.ScriptsButton, this.ScriptsTab),
				new KeyValuePair<TabCheckBox, Grid>(this.SettingsButton, this.SettingsTab)
			};
			KeyValuePair<TabCheckBox, Grid>[] tabCheckBoxes = CS$<>8__locals1.tabCheckBoxes;
			for (int i = 0; i < tabCheckBoxes.Length; i++)
			{
				MainWindow.<>c__DisplayClass48_1 CS$<>8__locals2 = new MainWindow.<>c__DisplayClass48_1();
				CS$<>8__locals2.CS$<>8__locals1 = CS$<>8__locals1;
				CS$<>8__locals2.tab = tabCheckBoxes[i];
				CS$<>8__locals2.tab.Value.Visibility = Visibility.Collapsed;
				TabCheckBox checkBox = CS$<>8__locals2.tab.Key;
				checkBox.OnEnabled += delegate(object sender, EventArgs e)
				{
					checkBox.CanToggle = false;
					CS$<>8__locals2.tab.Value.Visibility = Visibility.Visible;
					foreach (KeyValuePair<TabCheckBox, Grid> keyValuePair in CS$<>8__locals2.CS$<>8__locals1.tabCheckBoxes)
					{
						TabCheckBox key = keyValuePair.Key;
						if (key.Enabled && key != checkBox)
						{
							key.CanToggle = true;
							key.Enabled = false;
						}
					}
				};
				checkBox.OnDisabled += delegate(object sender, EventArgs e)
				{
					CS$<>8__locals2.tab.Value.Visibility = Visibility.Collapsed;
				};
			}
			KeyValuePair<Button, Grid>[] array = new KeyValuePair<Button, Grid>[]
			{
				new KeyValuePair<Button, Grid>(this.ExecutorHeaderButton, this.ExecutorHeader),
				new KeyValuePair<Button, Grid>(this.EditorHeaderButton, this.EditorHeader),
				new KeyValuePair<Button, Grid>(this.AIHeaderButton, this.AIHeader)
			};
			for (int i = 0; i < array.Length; i++)
			{
				KeyValuePair<Button, Grid> settingsCategory = array[i];
				settingsCategory.Key.Click += delegate(object sender, RoutedEventArgs e)
				{
					CS$<>8__locals1.<>4__this.SettingsScroll.ScrollToVerticalOffset(settingsCategory.Value.TranslatePoint(default(Point), CS$<>8__locals1.<>4__this.SettingsStack).Y);
				};
			}
			this.LoginPopupGrid.Opacity = 0.0;
			this.MainBlur.Radius = 0.0;
			this.NotificationBorder.Width = 0.0;
			this.HideAdPane();
			CS$<>8__locals1.tabCheckBoxes[1].Key.Enabled = true;
			this.aiChat = new AIChat();
		}

		// Token: 0x06000032 RID: 50 RVA: 0x0000328D File Offset: 0x0000148D
		private void HomeWindow_Loaded(object sender, RoutedEventArgs e)
		{
			this.InitiateLogin();
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003295 File Offset: 0x00001495
		private void HomeWindow_Closing(object sender, CancelEventArgs e)
		{
			if (Settings.Instance.SaveTabs)
			{
				this.AutoSaveTabs();
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x000032A9 File Offset: 0x000014A9
		private void HomeWindow_SourceInitialized(object sender, EventArgs e)
		{
			HwndSource.FromHwnd(new WindowInteropHelper(this).Handle).AddHook(new HwndSourceHook(MainWindow.WindowProc));
		}

		// Token: 0x06000035 RID: 53 RVA: 0x000032CC File Offset: 0x000014CC
		private void HomeWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Left)
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000036 RID: 54 RVA: 0x000032FC File Offset: 0x000014FC
		private void HomeWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (base.WindowState != this.previousWindowState)
			{
				this.previousWindowState = base.WindowState;
				this.MaximiseButton.Content = ((base.WindowState == WindowState.Maximized) ? this.exitFullscreenPath : this.fullscreenPath);
			}
		}

		// Token: 0x06000037 RID: 55 RVA: 0x0000333A File Offset: 0x0000153A
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			Environment.Exit(0);
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00003342 File Offset: 0x00001542
		private void MaximiseButton_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = ((base.WindowState == WindowState.Maximized) ? WindowState.Normal : WindowState.Maximized);
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00003357 File Offset: 0x00001557
		private void MinimiseButton_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00003360 File Offset: 0x00001560
		private void NewTabButton_Click(object sender, RoutedEventArgs e)
		{
			this.NewTab("x", "print('Hello World!');", true);
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00003374 File Offset: 0x00001574
		private void CloseTabButton_Click(object sender, RoutedEventArgs e)
		{
			TabItem tabItem = (TabItem)((Button)sender).TemplatedParent;
			this.RemoveTab((string)tabItem.Header);
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000033A3 File Offset: 0x000015A3
		private void TabHeaderScroll_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			if (e.ExtentWidthChange > 0.0)
			{
				((ScrollViewer)sender).ScrollToRightEnd();
			}
		}

		// Token: 0x0600003D RID: 61 RVA: 0x000033C4 File Offset: 0x000015C4
		private async void ExecuteButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.selectedProcessId != null)
			{
				int[] array = new int[] { this.selectedProcessId.Value };
				JavascriptResponse javascriptResponse = await ((ChromiumWebBrowser)this.ScriptTabs.SelectedContent).EvaluateScriptAsync("window.getText();", null, false);
				Roblox.ExecuteSpecific(array, javascriptResponse.Result.ToString());
				array = null;
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x000033FB File Offset: 0x000015FB
		private void ClearButton_Click(object sender, RoutedEventArgs e)
		{
			((ChromiumWebBrowser)this.ScriptTabs.SelectedContent).ExecuteScriptAsync("window.setText('');");
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00003418 File Offset: 0x00001618
		private void OpenFileButton_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Title = "Wave - Open Script",
				Filter = "Lua Script|*.lua|Text File|*.txt"
			};
			bool? flag = openFileDialog.ShowDialog();
			bool flag2 = true;
			if ((flag.GetValueOrDefault() == flag2) & (flag != null))
			{
				this.NewTab(global::System.IO.Path.GetFileName(openFileDialog.FileName), File.ReadAllText(openFileDialog.FileName), true);
			}
		}

		// Token: 0x06000040 RID: 64 RVA: 0x0000347C File Offset: 0x0000167C
		private async void SaveFileButton_Click(object sender, RoutedEventArgs e)
		{
			Encoding encoding = Encoding.UTF8;
			JavascriptResponse javascriptResponse = await ((ChromiumWebBrowser)this.ScriptTabs.SelectedContent).EvaluateScriptAsync("window.getText();", null, false);
			byte[] bytes = encoding.GetBytes(javascriptResponse.Result.ToString());
			encoding = null;
			SaveFileDialog saveFileDialog = new SaveFileDialog
			{
				Title = "Wave - Save Script",
				Filter = "Lua Script|*.lua"
			};
			bool? flag = saveFileDialog.ShowDialog();
			bool flag2 = true;
			if ((flag.GetValueOrDefault() == flag2) & (flag != null))
			{
				FileStream fileStream = (FileStream)saveFileDialog.OpenFile();
				fileStream.Write(bytes, 0, bytes.Length);
				fileStream.Close();
			}
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000034B4 File Offset: 0x000016B4
		private void AIToggleButton_Click(object sender, RoutedEventArgs e)
		{
			this.isAIPanelOpen = !this.isAIPanelOpen;
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.AIChatScroll)
				{
					Property = FrameworkElement.WidthProperty,
					To = (this.isAIPanelOpen ? 216 : 0)
				},
				new AnimationPropertyBase(this.AIInputGrid)
				{
					Property = FrameworkElement.WidthProperty,
					To = (this.isAIPanelOpen ? 216 : 0)
				}
			});
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00003544 File Offset: 0x00001744
		private void AIInput_GotFocus(object sender, RoutedEventArgs e)
		{
			this.AIInput.Text = "";
		}

		// Token: 0x06000043 RID: 67 RVA: 0x00003556 File Offset: 0x00001756
		private void AIInput_LostFocus(object sender, RoutedEventArgs e)
		{
			this.AIInput.Text = "Send a message...";
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00003568 File Offset: 0x00001768
		private void AIInput_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				if (this.AIInput.Text.Length > 0)
				{
					this.SendAIMessage(this.AIInput.Text);
				}
				FocusManager.SetFocusedElement(FocusManager.GetFocusScope(this.AIInput), null);
				Keyboard.ClearFocus();
				this.AIInput.Text = "Send a message...";
			}
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000035C8 File Offset: 0x000017C8
		private void SearchQuery_GotFocus(object sender, RoutedEventArgs e)
		{
			this.SearchQuery.Text = "";
		}

		// Token: 0x06000046 RID: 70 RVA: 0x000035DC File Offset: 0x000017DC
		private void SearchQuery_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				FocusManager.SetFocusedElement(FocusManager.GetFocusScope(this.SearchQuery), null);
				Keyboard.ClearFocus();
				this.SearchScripts(this.SearchQuery.Text, 1);
				if (this.SearchQuery.Text.Length == 0)
				{
					this.SearchQuery.Text = "Enter your search query...";
				}
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x0000363C File Offset: 0x0000183C
		private void SearchQuery_LostFocus(object sender, RoutedEventArgs e)
		{
			if (this.SearchQuery.Text.Length == 0)
			{
				this.SearchQuery.Text = "Enter your search query...";
			}
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003660 File Offset: 0x00001860
		private void SearchBtn_Click(object sender, RoutedEventArgs e)
		{
			this.SearchScripts(this.SearchQuery.Text, 1);
			if (this.SearchQuery.Text.Length == 0)
			{
				this.SearchQuery.Text = "Enter your search query...";
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00003696 File Offset: 0x00001896
		private void NextPageBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.currentPage < this.totalPages)
			{
				this.SearchScripts(this.lastQuery, this.currentPage + 1);
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000036BA File Offset: 0x000018BA
		private void PreviousPageBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.currentPage > 1)
			{
				this.SearchScripts(this.lastQuery, this.currentPage - 1);
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x000036D9 File Offset: 0x000018D9
		private void ScriptBloxCredits_Click(object sender, RoutedEventArgs e)
		{
			Process.Start("https://scriptblox.com");
		}

		// Token: 0x0600004C RID: 76 RVA: 0x000036E6 File Offset: 0x000018E6
		private void CloseNotificationButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.currentNotification.GetCurrentState() == ClockState.Active)
			{
				this.currentNotification.Stop();
				this.CloseNotification();
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00003706 File Offset: 0x00001906
		private void CloseAdButton_Click(object sender, RoutedEventArgs e)
		{
			this.HideAdPane();
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000370E File Offset: 0x0000190E
		private void AdBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			Process.Start(this.currentAdvertisement.redirectLink);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00003721 File Offset: 0x00001921
		private void MultiInstance_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.MultiInstance = this.MultiInstance.IsChecked;
			Settings.Instance.Save();
			Bloxstrap.Instance.MultiInstanceLaunching = this.MultiInstance.IsChecked;
			Bloxstrap.Instance.Save();
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00003761 File Offset: 0x00001961
		private void AutoExecute_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.AutoExecute = this.AutoExecute.IsChecked;
			Settings.Instance.Save();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00003784 File Offset: 0x00001984
		private void SaveTabs_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.SaveTabs = this.SaveTabs.IsChecked;
			Settings.Instance.Save();
			if (this.isTransferredToUI)
			{
				if (this.SaveTabs.IsChecked)
				{
					this.AutoSaveTabs();
					this.saveTabTimer.Start();
					return;
				}
				this.saveTabTimer.Stop();
				string[] files = Directory.GetFiles("data/tabs");
				for (int i = 0; i < files.Length; i++)
				{
					File.Delete(files[i]);
				}
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00003804 File Offset: 0x00001A04
		private void EditorRefreshRate_OnValueChanged(object sender, EventArgs e)
		{
			Settings.Instance.EditorRefreshRate = (int)this.EditorRefreshRate.Value;
			Settings.Instance.Save();
			foreach (object obj in ((IEnumerable)this.ScriptTabs.Items))
			{
				((ChromiumWebBrowser)((TabItem)obj).Content).GetBrowserHost().WindowlessFrameRate = Settings.Instance.EditorRefreshRate;
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00003898 File Offset: 0x00001A98
		private void EditorTextSize_OnValueChanged(object sender, EventArgs e)
		{
			Settings.Instance.EditorTextSize = this.EditorTextSize.Value;
			Settings.Instance.Save();
			foreach (object obj in ((IEnumerable)this.ScriptTabs.Items))
			{
				((ChromiumWebBrowser)((TabItem)obj).Content).ExecuteScriptAsync("window.updateOptions({ fontSize: " + Settings.Instance.EditorTextSize.ToString() + " });");
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x0000393C File Offset: 0x00001B3C
		private void ShowMinimap_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.ShowMinimap = this.ShowMinimap.IsChecked;
			Settings.Instance.Save();
			foreach (object obj in ((IEnumerable)this.ScriptTabs.Items))
			{
				((ChromiumWebBrowser)((TabItem)obj).Content).ExecuteScriptAsync("window.updateOptions({ minimap: { enabled: " + Settings.Instance.ShowMinimap.ToString().ToLower() + "} });");
			}
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000039E4 File Offset: 0x00001BE4
		private void ShowInlayHints_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.ShowInlayHints = this.ShowInlayHints.IsChecked;
			Settings.Instance.Save();
			foreach (object obj in ((IEnumerable)this.ScriptTabs.Items))
			{
				((ChromiumWebBrowser)((TabItem)obj).Content).ExecuteScriptAsync("window.updateOptions({ inlayHints: { enabled: " + Settings.Instance.ShowInlayHints.ToString().ToLower() + "} });");
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00003A8C File Offset: 0x00001C8C
		private void UseConversationHistory_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.UseConversationHistory = this.UseConversationHistory.IsChecked;
			Settings.Instance.Save();
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00003AAD File Offset: 0x00001CAD
		private void TopMost_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.TopMost = this.TopMost.IsChecked;
			Settings.Instance.Save();
			base.Topmost = this.TopMost.IsChecked;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00003ADF File Offset: 0x00001CDF
		private void AppendCurrentScript_OnCheckedChanged(object sender, EventArgs e)
		{
			Settings.Instance.AppendCurrentScript = this.AppendCurrentScript.IsChecked;
			Settings.Instance.Save();
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00003B00 File Offset: 0x00001D00
		private void ClearConversationHistory_OnClicked(object sender, EventArgs e)
		{
			this.aiChat.ClearConversationHistory();
			this.AIChatPanel.Children.RemoveRange(1, this.AIChatPanel.Children.Count - 1);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00003B30 File Offset: 0x00001D30
		private void AIChatScroll_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			if (e.ExtentHeightChange > 0.0)
			{
				this.AIChatScroll.ScrollToBottom();
			}
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00003B4E File Offset: 0x00001D4E
		private void CloseInstanceButton_Click(object sender, RoutedEventArgs e)
		{
			this.AnimatePopupOut(this.InstancePopupGrid);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00003B60 File Offset: 0x00001D60
		private async void SelectedProcessButton_Click(object sender, RoutedEventArgs e)
		{
			string text = (await ((ChromiumWebBrowser)this.ScriptTabs.SelectedContent).EvaluateScriptAsync("window.getText();", null, false)).Result.ToString();
			foreach (object obj in this.InstanceStack.Children)
			{
				((InstancePanel)obj).Script = text;
			}
			this.AnimatePopupIn(this.InstancePopupGrid);
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00004548 File Offset: 0x00002748
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((ScrollViewer)target).ScrollChanged += this.TabHeaderScroll_ScrollChanged;
				return;
			case 3:
				((Button)target).Click += this.NewTabButton_Click;
				return;
			case 4:
				((Button)target).Click += this.CloseTabButton_Click;
				return;
			default:
				return;
			}
		}

		// Token: 0x04000007 RID: 7
		private readonly string fullscreenPath = "M200-200h80q17 0 28.5 11.5T320-160q0 17-11.5 28.5T280-120H160q-17 0-28.5-11.5T120-160v-120q0-17 11.5-28.5T160-320q17 0 28.5 11.5T200-280v80Zm560 0v-80q0-17 11.5-28.5T800-320q17 0 28.5 11.5T840-280v120q0 17-11.5 28.5T800-120H680q-17 0-28.5-11.5T640-160q0-17 11.5-28.5T680-200h80ZM200-760v80q0 17-11.5 28.5T160-640q-17 0-28.5-11.5T120-680v-120q0-17 11.5-28.5T160-840h120q17 0 28.5 11.5T320-800q0 17-11.5 28.5T280-760h-80Zm560 0h-80q-17 0-28.5-11.5T640-800q0-17 11.5-28.5T680-840h120q17 0 28.5 11.5T840-800v120q0 17-11.5 28.5T800-640q-17 0-28.5-11.5T760-680v-80Z";

		// Token: 0x04000008 RID: 8
		private readonly string exitFullscreenPath = "M240-240h-80q-17 0-28.5-11.5T120-280q0-17 11.5-28.5T160-320h120q17 0 28.5 11.5T320-280v120q0 17-11.5 28.5T280-120q-17 0-28.5-11.5T240-160v-80Zm480 0v80q0 17-11.5 28.5T680-120q-17 0-28.5-11.5T640-160v-120q0-17 11.5-28.5T680-320h120q17 0 28.5 11.5T840-280q0 17-11.5 28.5T800-240h-80ZM240-720v-80q0-17 11.5-28.5T280-840q17 0 28.5 11.5T320-800v120q0 17-11.5 28.5T280-640H160q-17 0-28.5-11.5T120-680q0-17 11.5-28.5T160-720h80Zm480 0h80q17 0 28.5 11.5T840-680q0 17-11.5 28.5T800-640H680q-17 0-28.5-11.5T640-680v-120q0-17 11.5-28.5T680-840q17 0 28.5 11.5T720-800v80Z";

		// Token: 0x04000009 RID: 9
		private WindowState previousWindowState;

		// Token: 0x0400000A RID: 10
		private bool isTransferredToUI;

		// Token: 0x0400000B RID: 11
		private int? selectedProcessId;

		// Token: 0x0400000C RID: 12
		private readonly Dictionary<string, int> notifications = new Dictionary<string, int>();

		// Token: 0x0400000D RID: 13
		private Storyboard currentNotification;

		// Token: 0x0400000E RID: 14
		private bool isNotifying;

		// Token: 0x0400000F RID: 15
		private int tabReferences;

		// Token: 0x04000010 RID: 16
		private readonly AIChat aiChat;

		// Token: 0x04000011 RID: 17
		private bool isAIPanelOpen = true;

		// Token: 0x04000012 RID: 18
		private int aiReferences;

		// Token: 0x04000013 RID: 19
		private bool isSearching;

		// Token: 0x04000014 RID: 20
		private string lastQuery;

		// Token: 0x04000015 RID: 21
		private int currentPage = 1;

		// Token: 0x04000016 RID: 22
		private int totalPages = 1;

		// Token: 0x04000017 RID: 23
		private Advertisement currentAdvertisement;

		// Token: 0x04000018 RID: 24
		private readonly Timer saveTabTimer = new Timer(60000.0);

		// Token: 0x02000029 RID: 41
		public struct POINT
		{
			// Token: 0x0600013F RID: 319 RVA: 0x00007636 File Offset: 0x00005836
			public POINT(int x, int y)
			{
				this.x = x;
				this.y = y;
			}

			// Token: 0x0400015C RID: 348
			public int x;

			// Token: 0x0400015D RID: 349
			public int y;
		}

		// Token: 0x0200002A RID: 42
		public struct MINMAXINFO
		{
			// Token: 0x0400015E RID: 350
			public MainWindow.POINT ptReserved;

			// Token: 0x0400015F RID: 351
			public MainWindow.POINT ptMaxSize;

			// Token: 0x04000160 RID: 352
			public MainWindow.POINT ptMaxPosition;

			// Token: 0x04000161 RID: 353
			public MainWindow.POINT ptMinTrackSize;

			// Token: 0x04000162 RID: 354
			public MainWindow.POINT ptMaxTrackSize;
		}

		// Token: 0x0200002B RID: 43
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		public class MONITORINFO
		{
			// Token: 0x04000163 RID: 355
			public int cbSize = Marshal.SizeOf(typeof(MainWindow.MONITORINFO));

			// Token: 0x04000164 RID: 356
			public MainWindow.RECT rcMonitor;

			// Token: 0x04000165 RID: 357
			public MainWindow.RECT rcWork;

			// Token: 0x04000166 RID: 358
			public int dwFlags;
		}

		// Token: 0x0200002C RID: 44
		public struct RECT
		{
			// Token: 0x1700002F RID: 47
			// (get) Token: 0x06000141 RID: 321 RVA: 0x00007663 File Offset: 0x00005863
			public int Width
			{
				get
				{
					return Math.Abs(this.right - this.left);
				}
			}

			// Token: 0x17000030 RID: 48
			// (get) Token: 0x06000142 RID: 322 RVA: 0x00007677 File Offset: 0x00005877
			public int Height
			{
				get
				{
					return this.bottom - this.top;
				}
			}

			// Token: 0x06000143 RID: 323 RVA: 0x00007686 File Offset: 0x00005886
			public RECT(int left, int top, int right, int bottom)
			{
				this.left = left;
				this.top = top;
				this.right = right;
				this.bottom = bottom;
			}

			// Token: 0x06000144 RID: 324 RVA: 0x000076A5 File Offset: 0x000058A5
			public RECT(MainWindow.RECT rcSrc)
			{
				this.left = rcSrc.left;
				this.top = rcSrc.top;
				this.right = rcSrc.right;
				this.bottom = rcSrc.bottom;
			}

			// Token: 0x17000031 RID: 49
			// (get) Token: 0x06000145 RID: 325 RVA: 0x000076D7 File Offset: 0x000058D7
			public bool IsEmpty
			{
				get
				{
					return this.left >= this.right || this.top >= this.bottom;
				}
			}

			// Token: 0x06000146 RID: 326 RVA: 0x000076FC File Offset: 0x000058FC
			public override string ToString()
			{
				if (this == MainWindow.RECT.Empty)
				{
					return "RECT {Empty}";
				}
				return string.Concat(new string[]
				{
					"RECT { left : ",
					this.left.ToString(),
					" / top : ",
					this.top.ToString(),
					" / right : ",
					this.right.ToString(),
					" / bottom : ",
					this.bottom.ToString(),
					" }"
				});
			}

			// Token: 0x06000147 RID: 327 RVA: 0x0000778D File Offset: 0x0000598D
			public override bool Equals(object obj)
			{
				return obj is Rect && this == (MainWindow.RECT)obj;
			}

			// Token: 0x06000148 RID: 328 RVA: 0x000077AA File Offset: 0x000059AA
			public override int GetHashCode()
			{
				return this.left.GetHashCode() + this.top.GetHashCode() + this.right.GetHashCode() + this.bottom.GetHashCode();
			}

			// Token: 0x06000149 RID: 329 RVA: 0x000077DB File Offset: 0x000059DB
			public static bool operator ==(MainWindow.RECT rect1, MainWindow.RECT rect2)
			{
				return rect1.left == rect2.left && rect1.top == rect2.top && rect1.right == rect2.right && rect1.bottom == rect2.bottom;
			}

			// Token: 0x0600014A RID: 330 RVA: 0x00007817 File Offset: 0x00005A17
			public static bool operator !=(MainWindow.RECT rect1, MainWindow.RECT rect2)
			{
				return !(rect1 == rect2);
			}

			// Token: 0x04000167 RID: 359
			public int left;

			// Token: 0x04000168 RID: 360
			public int top;

			// Token: 0x04000169 RID: 361
			public int right;

			// Token: 0x0400016A RID: 362
			public int bottom;

			// Token: 0x0400016B RID: 363
			public static readonly MainWindow.RECT Empty;
		}
	}
}
