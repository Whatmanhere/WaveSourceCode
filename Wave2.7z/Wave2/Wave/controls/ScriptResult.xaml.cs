﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Wave.Classes.Passive;

namespace Wave.Controls
{
	// Token: 0x0200000D RID: 13
	public partial class ScriptResult : UserControl
	{
		// Token: 0x06000093 RID: 147 RVA: 0x00004DEB File Offset: 0x00002FEB
		public ScriptResult()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00004DFC File Offset: 0x00002FFC
		public ScriptResult(ScriptObject scriptObj)
		{
			ScriptResult <>4__this = this;
			this.scriptObject = scriptObj;
			scriptObj.Correct();
			this.InitializeComponent();
			ImageBrush background404 = (ImageBrush)this.Icon.Background;
			BitmapImage bitmapImage = new BitmapImage();
			bitmapImage.DownloadFailed += delegate(object sender, ExceptionEventArgs e)
			{
				<>4__this.Icon.Background = background404;
			};
			bitmapImage.BeginInit();
			bitmapImage.UriSource = new Uri(scriptObj.game.imageUrl, UriKind.Absolute);
			bitmapImage.EndInit();
			this.Icon.Background = new ImageBrush
			{
				ImageSource = bitmapImage
			};
			this.Title.Content = scriptObj.title;
			this.Created.Content = "Created: " + scriptObj.createdAt.ToShortDateString();
			this.Views.Content = "Views: " + scriptObj.views.ToString("#,##0");
			if (!scriptObj.isPatched)
			{
				this.Patched.Visibility = Visibility.Collapsed;
			}
			if (!scriptObj.isUniversal)
			{
				this.Universal.Visibility = Visibility.Collapsed;
			}
			if (!scriptObj.key)
			{
				this.Key.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x040000A2 RID: 162
		public ScriptObject scriptObject;
	}
}
