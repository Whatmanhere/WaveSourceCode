﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Wave.Classes.Cosmetic;

namespace Wave.Controls.Settings
{
	// Token: 0x02000010 RID: 16
	public partial class SettingSlider : UserControl
	{
		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000BB RID: 187 RVA: 0x000057D0 File Offset: 0x000039D0
		// (set) Token: 0x060000BC RID: 188 RVA: 0x000057E2 File Offset: 0x000039E2
		public double Value
		{
			get
			{
				return (double)base.GetValue(SettingSlider.ValueProperty);
			}
			set
			{
				base.SetValue(SettingSlider.ValueProperty, value);
				EventHandler<EventArgs> onValueChanged = this.OnValueChanged;
				if (onValueChanged == null)
				{
					return;
				}
				onValueChanged(this, new EventArgs());
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000BD RID: 189 RVA: 0x0000580B File Offset: 0x00003A0B
		// (set) Token: 0x060000BE RID: 190 RVA: 0x0000581D File Offset: 0x00003A1D
		public int MinimumValue
		{
			get
			{
				return (int)base.GetValue(SettingSlider.MinimumValueProperty);
			}
			set
			{
				base.SetValue(SettingSlider.MinimumValueProperty, value);
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000BF RID: 191 RVA: 0x00005830 File Offset: 0x00003A30
		// (set) Token: 0x060000C0 RID: 192 RVA: 0x00005842 File Offset: 0x00003A42
		public int MaximumValue
		{
			get
			{
				return (int)base.GetValue(SettingSlider.MaximumValueProperty);
			}
			set
			{
				base.SetValue(SettingSlider.MaximumValueProperty, value);
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000C1 RID: 193 RVA: 0x00005855 File Offset: 0x00003A55
		// (set) Token: 0x060000C2 RID: 194 RVA: 0x00005867 File Offset: 0x00003A67
		public double RoundingFactor
		{
			get
			{
				return (double)base.GetValue(SettingSlider.RoundingFactorProperty);
			}
			set
			{
				base.SetValue(SettingSlider.RoundingFactorProperty, value);
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000C3 RID: 195 RVA: 0x0000587A File Offset: 0x00003A7A
		// (set) Token: 0x060000C4 RID: 196 RVA: 0x0000588C File Offset: 0x00003A8C
		public string Title
		{
			get
			{
				return (string)base.GetValue(SettingSlider.TitleProperty);
			}
			set
			{
				base.SetValue(SettingSlider.TitleProperty, value);
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x0000589A File Offset: 0x00003A9A
		// (set) Token: 0x060000C6 RID: 198 RVA: 0x000058AC File Offset: 0x00003AAC
		public string Description
		{
			get
			{
				return (string)base.GetValue(SettingSlider.DescriptionProperty);
			}
			set
			{
				base.SetValue(SettingSlider.DescriptionProperty, value);
			}
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060000C7 RID: 199 RVA: 0x000058BC File Offset: 0x00003ABC
		// (remove) Token: 0x060000C8 RID: 200 RVA: 0x000058F4 File Offset: 0x00003AF4
		public event EventHandler<EventArgs> OnValueChanged;

		// Token: 0x060000C9 RID: 201 RVA: 0x00005929 File Offset: 0x00003B29
		public SettingSlider()
		{
			this.InitializeComponent();
			this.OnValueChanged += delegate(object sender, EventArgs e)
			{
				this.IndicatorLabel.Content = this.Value.ToString();
				Animation.Animate(new AnimationPropertyBase[]
				{
					new AnimationPropertyBase(this.IndicatorHighlight)
					{
						Property = FrameworkElement.WidthProperty,
						To = Math.Round((this.Value - (double)this.MinimumValue) / (double)(this.MaximumValue - this.MinimumValue) * this.IndicatorGrid.ActualWidth)
					}
				});
			};
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000594C File Offset: 0x00003B4C
		private void SettingSliderControl_Loaded(object sender, RoutedEventArgs e)
		{
			this.IndicatorLabel.Content = this.Value.ToString();
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.IndicatorHighlight)
				{
					Property = FrameworkElement.WidthProperty,
					To = Math.Round((this.Value - (double)this.MinimumValue) / (double)(this.MaximumValue - this.MinimumValue) * this.IndicatorGrid.ActualWidth)
				}
			});
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000059D0 File Offset: 0x00003BD0
		private async void IndicatorBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			while (Mouse.LeftButton == MouseButtonState.Pressed)
			{
				double num = Math.Min(Math.Max(Mouse.GetPosition(this.IndicatorGrid).X, 0.0), this.IndicatorGrid.ActualWidth) / this.IndicatorGrid.ActualWidth;
				double num2 = (double)this.MinimumValue + (double)(this.MaximumValue - this.MinimumValue) * num;
				this.Value = Math.Floor(num2 * (1.0 / this.RoundingFactor)) / (1.0 / this.RoundingFactor);
				await Task.Delay(33);
			}
		}

		// Token: 0x040000CD RID: 205
		public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(double), typeof(SettingSlider), new PropertyMetadata(0.0));

		// Token: 0x040000CE RID: 206
		public static readonly DependencyProperty MinimumValueProperty = DependencyProperty.Register("MinimumValue", typeof(int), typeof(SettingSlider), new PropertyMetadata(0));

		// Token: 0x040000CF RID: 207
		public static readonly DependencyProperty MaximumValueProperty = DependencyProperty.Register("MaximumValue", typeof(int), typeof(SettingSlider), new PropertyMetadata(100));

		// Token: 0x040000D0 RID: 208
		public static readonly DependencyProperty RoundingFactorProperty = DependencyProperty.Register("RoundingFactor", typeof(double), typeof(SettingSlider), new PropertyMetadata(1.0));

		// Token: 0x040000D1 RID: 209
		public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(string), typeof(SettingSlider), new PropertyMetadata("Title"));

		// Token: 0x040000D2 RID: 210
		public static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register("Description", typeof(string), typeof(SettingSlider), new PropertyMetadata("Description"));
	}
}
