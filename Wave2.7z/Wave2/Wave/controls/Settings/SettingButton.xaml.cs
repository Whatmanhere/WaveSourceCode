﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace Wave.Controls.Settings
{
	// Token: 0x0200000F RID: 15
	public partial class SettingButton : UserControl
	{
		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000AE RID: 174 RVA: 0x0000557A File Offset: 0x0000377A
		// (set) Token: 0x060000AF RID: 175 RVA: 0x0000558C File Offset: 0x0000378C
		public string Title
		{
			get
			{
				return (string)base.GetValue(SettingButton.TitleProperty);
			}
			set
			{
				base.SetValue(SettingButton.TitleProperty, value);
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000B0 RID: 176 RVA: 0x0000559A File Offset: 0x0000379A
		// (set) Token: 0x060000B1 RID: 177 RVA: 0x000055AC File Offset: 0x000037AC
		public string Description
		{
			get
			{
				return (string)base.GetValue(SettingButton.DescriptionProperty);
			}
			set
			{
				base.SetValue(SettingButton.DescriptionProperty, value);
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000B2 RID: 178 RVA: 0x000055BA File Offset: 0x000037BA
		// (set) Token: 0x060000B3 RID: 179 RVA: 0x000055CC File Offset: 0x000037CC
		public string Shorthand
		{
			get
			{
				return (string)base.GetValue(SettingButton.ShorthandProperty);
			}
			set
			{
				base.SetValue(SettingButton.ShorthandProperty, value);
			}
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060000B4 RID: 180 RVA: 0x000055DC File Offset: 0x000037DC
		// (remove) Token: 0x060000B5 RID: 181 RVA: 0x00005614 File Offset: 0x00003814
		public event EventHandler<EventArgs> OnClicked;

		// Token: 0x060000B6 RID: 182 RVA: 0x00005649 File Offset: 0x00003849
		public SettingButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00005657 File Offset: 0x00003857
		private void ClickButton_Click(object sender, RoutedEventArgs e)
		{
			EventHandler<EventArgs> onClicked = this.OnClicked;
			if (onClicked == null)
			{
				return;
			}
			onClicked(this, new EventArgs());
		}

		// Token: 0x040000C2 RID: 194
		public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(string), typeof(SettingButton), new PropertyMetadata("Title"));

		// Token: 0x040000C3 RID: 195
		public static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register("Description", typeof(string), typeof(SettingButton), new PropertyMetadata("Description"));

		// Token: 0x040000C4 RID: 196
		public static readonly DependencyProperty ShorthandProperty = DependencyProperty.Register("Shorthand", typeof(string), typeof(SettingButton), new PropertyMetadata("Shorthand"));
	}
}
