﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using Wave.Classes.Cosmetic;

namespace Wave.Controls.Settings
{
	// Token: 0x02000011 RID: 17
	public partial class SettingCheckBox : UserControl
	{
		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000D0 RID: 208 RVA: 0x00005CD4 File Offset: 0x00003ED4
		// (set) Token: 0x060000D1 RID: 209 RVA: 0x00005CE8 File Offset: 0x00003EE8
		public bool IsChecked
		{
			get
			{
				return (bool)base.GetValue(SettingCheckBox.IsCheckedProperty);
			}
			set
			{
				base.SetValue(SettingCheckBox.IsCheckedProperty, value);
				EventHandler<EventArgs> onCheckedChanged = this.OnCheckedChanged;
				if (onCheckedChanged != null)
				{
					onCheckedChanged(this, new EventArgs());
				}
				Animation.Animate(new AnimationPropertyBase[]
				{
					new AnimationPropertyBase(this.IndicatorPath)
					{
						Property = UIElement.OpacityProperty,
						To = ((value > false) ? 1 : 0)
					}
				});
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000D2 RID: 210 RVA: 0x00005D51 File Offset: 0x00003F51
		// (set) Token: 0x060000D3 RID: 211 RVA: 0x00005D63 File Offset: 0x00003F63
		public string Title
		{
			get
			{
				return (string)base.GetValue(SettingCheckBox.TitleProperty);
			}
			set
			{
				base.SetValue(SettingCheckBox.TitleProperty, value);
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000D4 RID: 212 RVA: 0x00005D71 File Offset: 0x00003F71
		// (set) Token: 0x060000D5 RID: 213 RVA: 0x00005D83 File Offset: 0x00003F83
		public string Description
		{
			get
			{
				return (string)base.GetValue(SettingCheckBox.DescriptionProperty);
			}
			set
			{
				base.SetValue(SettingCheckBox.DescriptionProperty, value);
			}
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060000D6 RID: 214 RVA: 0x00005D94 File Offset: 0x00003F94
		// (remove) Token: 0x060000D7 RID: 215 RVA: 0x00005DCC File Offset: 0x00003FCC
		public event EventHandler<EventArgs> OnCheckedChanged;

		// Token: 0x060000D8 RID: 216 RVA: 0x00005E01 File Offset: 0x00004001
		public SettingCheckBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00005E0F File Offset: 0x0000400F
		private void MainBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.IsChecked = !this.IsChecked;
		}

		// Token: 0x040000DE RID: 222
		public static readonly DependencyProperty IsCheckedProperty = DependencyProperty.Register("IsChecked", typeof(bool), typeof(SettingCheckBox), new PropertyMetadata(false));

		// Token: 0x040000DF RID: 223
		public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(string), typeof(SettingCheckBox), new PropertyMetadata("Title"));

		// Token: 0x040000E0 RID: 224
		public static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register("Description", typeof(string), typeof(SettingCheckBox), new PropertyMetadata("Description"));
	}
}
