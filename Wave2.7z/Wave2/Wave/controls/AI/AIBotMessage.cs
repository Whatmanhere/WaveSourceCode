﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace Wave.Controls.AI
{
	// Token: 0x02000013 RID: 19
	public class AIBotMessage : UserControl, IComponentConnector
	{
		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000E5 RID: 229 RVA: 0x000060EB File Offset: 0x000042EB
		// (set) Token: 0x060000E6 RID: 230 RVA: 0x000060FD File Offset: 0x000042FD
		public string Message
		{
			get
			{
				return (string)base.GetValue(AIBotMessage.MessageProperty);
			}
			set
			{
				base.SetValue(AIBotMessage.MessageProperty, value);
			}
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000610B File Offset: 0x0000430B
		public AIBotMessage()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0000611C File Offset: 0x0000431C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri uri = new Uri("/Wave;component/controls/aimessages/aibotmessage.xaml", UriKind.Relative);
			Application.LoadComponent(this, uri);
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0000614C File Offset: 0x0000434C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.AIBotMessageControl = (AIBotMessage)target;
				return;
			case 2:
				this.MainGrid = (Grid)target;
				return;
			case 3:
				this.MessageBlock = (TextBlock)target;
				return;
			case 4:
				this.Title = (Label)target;
				return;
			case 5:
				this.Sideline = (Border)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040000F2 RID: 242
		public static readonly DependencyProperty MessageProperty = DependencyProperty.Register("Message", typeof(string), typeof(AIBotMessage), new PropertyMetadata("~~ No Message Supplied ~~"));

		// Token: 0x040000F3 RID: 243
		internal AIBotMessage AIBotMessageControl;

		// Token: 0x040000F4 RID: 244
		internal Grid MainGrid;

		// Token: 0x040000F5 RID: 245
		internal TextBlock MessageBlock;

		// Token: 0x040000F6 RID: 246
		internal Label Title;

		// Token: 0x040000F7 RID: 247
		internal Border Sideline;

		// Token: 0x040000F8 RID: 248
		private bool _contentLoaded;
	}
}
