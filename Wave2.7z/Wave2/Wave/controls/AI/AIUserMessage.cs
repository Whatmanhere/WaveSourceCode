﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace Wave.Controls.AI
{
	// Token: 0x02000012 RID: 18
	public class AIUserMessage : UserControl, IComponentConnector
	{
		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000DD RID: 221 RVA: 0x00005F91 File Offset: 0x00004191
		// (set) Token: 0x060000DE RID: 222 RVA: 0x00005FA3 File Offset: 0x000041A3
		public string Username
		{
			get
			{
				return (string)base.GetValue(AIUserMessage.UsernameProperty);
			}
			set
			{
				base.SetValue(AIUserMessage.UsernameProperty, value);
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000DF RID: 223 RVA: 0x00005FB1 File Offset: 0x000041B1
		// (set) Token: 0x060000E0 RID: 224 RVA: 0x00005FC3 File Offset: 0x000041C3
		public string Message
		{
			get
			{
				return (string)base.GetValue(AIUserMessage.MessageProperty);
			}
			set
			{
				base.SetValue(AIUserMessage.MessageProperty, value);
			}
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00005FD1 File Offset: 0x000041D1
		public AIUserMessage()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x00005FE0 File Offset: 0x000041E0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri uri = new Uri("/Wave;component/controls/aimessages/aiusermessage.xaml", UriKind.Relative);
			Application.LoadComponent(this, uri);
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x00006010 File Offset: 0x00004210
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.AIUserMessageControl = (AIUserMessage)target;
				return;
			case 2:
				this.MainGrid = (Grid)target;
				return;
			case 3:
				this.MessageBlock = (TextBlock)target;
				return;
			case 4:
				this.Title = (Label)target;
				return;
			case 5:
				this.Sideline = (Border)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040000EA RID: 234
		public static readonly DependencyProperty UsernameProperty = DependencyProperty.Register("Username", typeof(string), typeof(AIUserMessage), new PropertyMetadata("Kieran"));

		// Token: 0x040000EB RID: 235
		public static readonly DependencyProperty MessageProperty = DependencyProperty.Register("Message", typeof(string), typeof(AIUserMessage), new PropertyMetadata("~~ No Message Supplied ~~"));

		// Token: 0x040000EC RID: 236
		internal AIUserMessage AIUserMessageControl;

		// Token: 0x040000ED RID: 237
		internal Grid MainGrid;

		// Token: 0x040000EE RID: 238
		internal TextBlock MessageBlock;

		// Token: 0x040000EF RID: 239
		internal Label Title;

		// Token: 0x040000F0 RID: 240
		internal Border Sideline;

		// Token: 0x040000F1 RID: 241
		private bool _contentLoaded;
	}
}
