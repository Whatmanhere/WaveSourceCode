﻿using System;

namespace Wave.Controls
{
	// Token: 0x0200000B RID: 11
	internal class ThumbnailResponseData
	{
		// Token: 0x0400009D RID: 157
		public double targetId;

		// Token: 0x0400009E RID: 158
		public string state;

		// Token: 0x0400009F RID: 159
		public string imageUrl;

		// Token: 0x040000A0 RID: 160
		public string version;
	}
}
