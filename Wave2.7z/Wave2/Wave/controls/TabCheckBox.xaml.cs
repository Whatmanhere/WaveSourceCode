﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Wave.Classes.Cosmetic;

namespace Wave.Controls
{
	// Token: 0x0200000E RID: 14
	public partial class TabCheckBox : UserControl
	{
		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000097 RID: 151 RVA: 0x0000508D File Offset: 0x0000328D
		// (set) Token: 0x06000098 RID: 152 RVA: 0x0000509F File Offset: 0x0000329F
		public bool CanToggle
		{
			get
			{
				return (bool)base.GetValue(TabCheckBox.CanToggleProperty);
			}
			set
			{
				base.SetValue(TabCheckBox.CanToggleProperty, value);
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000099 RID: 153 RVA: 0x000050B2 File Offset: 0x000032B2
		// (set) Token: 0x0600009A RID: 154 RVA: 0x000050C4 File Offset: 0x000032C4
		public bool Enabled
		{
			get
			{
				return (bool)base.GetValue(TabCheckBox.EnabledProperty);
			}
			set
			{
				if (!this.CanToggle)
				{
					return;
				}
				base.SetValue(TabCheckBox.EnabledProperty, value);
				if (value)
				{
					this.OnEnabled(this, new EventArgs());
					return;
				}
				this.OnDisabled(this, new EventArgs());
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600009B RID: 155 RVA: 0x00005111 File Offset: 0x00003311
		// (set) Token: 0x0600009C RID: 156 RVA: 0x00005123 File Offset: 0x00003323
		public string Icon
		{
			get
			{
				return (string)base.GetValue(TabCheckBox.IconProperty);
			}
			set
			{
				base.SetValue(TabCheckBox.IconProperty, value);
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600009D RID: 157 RVA: 0x00005131 File Offset: 0x00003331
		// (set) Token: 0x0600009E RID: 158 RVA: 0x00005143 File Offset: 0x00003343
		public bool IsIconUniform
		{
			get
			{
				return (bool)base.GetValue(TabCheckBox.IsIconUniformProperty);
			}
			set
			{
				base.SetValue(TabCheckBox.IsIconUniformProperty, value);
				this.IconPath.Stretch = (value ? Stretch.Uniform : Stretch.Fill);
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x0600009F RID: 159 RVA: 0x00005168 File Offset: 0x00003368
		// (set) Token: 0x060000A0 RID: 160 RVA: 0x0000517A File Offset: 0x0000337A
		public Brush BackgroundSelected
		{
			get
			{
				return (Brush)base.GetValue(TabCheckBox.BackgroundSelectedProperty);
			}
			set
			{
				base.SetValue(TabCheckBox.BackgroundSelectedProperty, value);
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x00005188 File Offset: 0x00003388
		// (set) Token: 0x060000A2 RID: 162 RVA: 0x0000519A File Offset: 0x0000339A
		public Brush IconSelected
		{
			get
			{
				return (Brush)base.GetValue(TabCheckBox.IconSelectedProperty);
			}
			set
			{
				base.SetValue(TabCheckBox.IconSelectedProperty, value);
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060000A3 RID: 163 RVA: 0x000051A8 File Offset: 0x000033A8
		// (remove) Token: 0x060000A4 RID: 164 RVA: 0x000051E0 File Offset: 0x000033E0
		public event EventHandler OnEnabled;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060000A5 RID: 165 RVA: 0x00005218 File Offset: 0x00003418
		// (remove) Token: 0x060000A6 RID: 166 RVA: 0x00005250 File Offset: 0x00003450
		public event EventHandler OnDisabled;

		// Token: 0x060000A7 RID: 167 RVA: 0x00005285 File Offset: 0x00003485
		public TabCheckBox()
		{
			this.InitializeComponent();
			this.OnEnabled += this.TabButton_OnEnabled;
			this.OnDisabled += this.TabButton_OnDisabled;
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x000052B8 File Offset: 0x000034B8
		private void TabButton_OnEnabled(object sender, EventArgs e)
		{
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.Highlight)
				{
					Property = UIElement.OpacityProperty,
					To = 1
				},
				new AnimationPropertyBase(this.IconHighlight)
				{
					Property = UIElement.OpacityProperty,
					To = 1
				}
			});
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x0000531C File Offset: 0x0000351C
		private void TabButton_OnDisabled(object sender, EventArgs e)
		{
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.Highlight)
				{
					Property = UIElement.OpacityProperty,
					To = 0
				},
				new AnimationPropertyBase(this.IconHighlight)
				{
					Property = UIElement.OpacityProperty,
					To = 0
				}
			});
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000537F File Offset: 0x0000357F
		private void MainGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.Enabled = !this.Enabled;
		}

		// Token: 0x040000B4 RID: 180
		public static readonly DependencyProperty CanToggleProperty = DependencyProperty.Register("CanToggle", typeof(bool), typeof(TabCheckBox), new PropertyMetadata(true));

		// Token: 0x040000B5 RID: 181
		public static readonly DependencyProperty EnabledProperty = DependencyProperty.Register("Enabled", typeof(bool), typeof(TabCheckBox), new PropertyMetadata(false));

		// Token: 0x040000B6 RID: 182
		public static readonly DependencyProperty IconProperty = DependencyProperty.Register("Icon", typeof(string), typeof(TabCheckBox), new PropertyMetadata(""));

		// Token: 0x040000B7 RID: 183
		public static readonly DependencyProperty IsIconUniformProperty = DependencyProperty.Register("IsIconUniform", typeof(bool), typeof(TabCheckBox), new PropertyMetadata(false));

		// Token: 0x040000B8 RID: 184
		public static readonly DependencyProperty BackgroundSelectedProperty = DependencyProperty.Register("BackgroundSelected", typeof(Brush), typeof(TabCheckBox), new PropertyMetadata(new SolidColorBrush(Color.FromRgb(29, 29, 30))));

		// Token: 0x040000B9 RID: 185
		public static readonly DependencyProperty IconSelectedProperty = DependencyProperty.Register("IconSelected", typeof(Brush), typeof(TabCheckBox), new PropertyMetadata(new SolidColorBrush(Colors.White)));
	}
}
