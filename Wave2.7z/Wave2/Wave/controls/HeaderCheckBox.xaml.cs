﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Wave.Classes.Cosmetic;

namespace Wave.Controls
{
	// Token: 0x02000009 RID: 9
	public partial class HeaderCheckBox : UserControl
	{
		// Token: 0x17000008 RID: 8
		// (get) Token: 0x0600006D RID: 109 RVA: 0x00004688 File Offset: 0x00002888
		// (set) Token: 0x0600006E RID: 110 RVA: 0x0000469A File Offset: 0x0000289A
		public bool CanToggle
		{
			get
			{
				return (bool)base.GetValue(HeaderCheckBox.CanToggleProperty);
			}
			set
			{
				base.SetValue(HeaderCheckBox.CanToggleProperty, value);
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600006F RID: 111 RVA: 0x000046AD File Offset: 0x000028AD
		// (set) Token: 0x06000070 RID: 112 RVA: 0x000046C0 File Offset: 0x000028C0
		public bool Enabled
		{
			get
			{
				return (bool)base.GetValue(HeaderCheckBox.EnabledProperty);
			}
			set
			{
				if (!this.CanToggle)
				{
					return;
				}
				base.SetValue(HeaderCheckBox.EnabledProperty, value);
				if (value)
				{
					this.OnEnabled(this, new EventArgs());
					return;
				}
				this.OnDisabled(this, new EventArgs());
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000071 RID: 113 RVA: 0x0000470D File Offset: 0x0000290D
		// (set) Token: 0x06000072 RID: 114 RVA: 0x0000471F File Offset: 0x0000291F
		public string Title
		{
			get
			{
				return (string)base.GetValue(HeaderCheckBox.TitleProperty);
			}
			set
			{
				base.SetValue(HeaderCheckBox.TitleProperty, value);
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000073 RID: 115 RVA: 0x0000472D File Offset: 0x0000292D
		// (set) Token: 0x06000074 RID: 116 RVA: 0x0000473F File Offset: 0x0000293F
		public Brush BackgroundSelected
		{
			get
			{
				return (Brush)base.GetValue(HeaderCheckBox.BackgroundSelectedProperty);
			}
			set
			{
				base.SetValue(HeaderCheckBox.BackgroundSelectedProperty, value);
			}
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000075 RID: 117 RVA: 0x00004750 File Offset: 0x00002950
		// (remove) Token: 0x06000076 RID: 118 RVA: 0x00004788 File Offset: 0x00002988
		public event EventHandler OnEnabled;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000077 RID: 119 RVA: 0x000047C0 File Offset: 0x000029C0
		// (remove) Token: 0x06000078 RID: 120 RVA: 0x000047F8 File Offset: 0x000029F8
		public event EventHandler OnDisabled;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000079 RID: 121 RVA: 0x00004830 File Offset: 0x00002A30
		// (remove) Token: 0x0600007A RID: 122 RVA: 0x00004868 File Offset: 0x00002A68
		public event EventHandler OnCloseClick;

		// Token: 0x0600007B RID: 123 RVA: 0x0000489D File Offset: 0x00002A9D
		public HeaderCheckBox()
		{
			this.InitializeComponent();
			this.OnEnabled += this.TabButton_OnEnabled;
			this.OnDisabled += this.TabButton_OnDisabled;
		}

		// Token: 0x0600007C RID: 124 RVA: 0x000048CF File Offset: 0x00002ACF
		private void TabButton_OnEnabled(object sender, EventArgs e)
		{
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.Highlight)
				{
					Property = UIElement.OpacityProperty,
					To = 1
				}
			});
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00004902 File Offset: 0x00002B02
		private void TabButton_OnDisabled(object sender, EventArgs e)
		{
			Animation.Animate(new AnimationPropertyBase[]
			{
				new AnimationPropertyBase(this.Highlight)
				{
					Property = UIElement.OpacityProperty,
					To = 0
				}
			});
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00004935 File Offset: 0x00002B35
		private void MainGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.Enabled = !this.Enabled;
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00004946 File Offset: 0x00002B46
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			this.OnCloseClick(sender, e);
		}

		// Token: 0x04000080 RID: 128
		public static readonly DependencyProperty CanToggleProperty = DependencyProperty.Register("CanToggle", typeof(bool), typeof(HeaderCheckBox), new PropertyMetadata(true));

		// Token: 0x04000081 RID: 129
		public static readonly DependencyProperty EnabledProperty = DependencyProperty.Register("Enabled", typeof(bool), typeof(HeaderCheckBox), new PropertyMetadata(false));

		// Token: 0x04000082 RID: 130
		public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(string), typeof(HeaderCheckBox), new PropertyMetadata("Untitled.lua"));

		// Token: 0x04000083 RID: 131
		public static readonly DependencyProperty BackgroundSelectedProperty = DependencyProperty.Register("BackgroundSelected", typeof(Brush), typeof(HeaderCheckBox), new PropertyMetadata(new SolidColorBrush(Color.FromRgb(29, 29, 30))));
	}
}
