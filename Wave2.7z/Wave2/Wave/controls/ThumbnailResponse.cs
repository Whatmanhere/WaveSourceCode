﻿using System;

namespace Wave.Controls
{
	// Token: 0x0200000C RID: 12
	internal class ThumbnailResponse
	{
		// Token: 0x040000A1 RID: 161
		public ThumbnailResponseData[] Data;
	}
}
