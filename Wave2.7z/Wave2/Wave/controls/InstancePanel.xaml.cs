﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Newtonsoft.Json;
using Wave.Classes.Implementations;

namespace Wave.Controls
{
	// Token: 0x0200000A RID: 10
	public partial class InstancePanel : UserControl
	{
		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000083 RID: 131 RVA: 0x00004AFA File Offset: 0x00002CFA
		// (set) Token: 0x06000084 RID: 132 RVA: 0x00004B0C File Offset: 0x00002D0C
		public string Username
		{
			get
			{
				return (string)base.GetValue(InstancePanel.UsernameProperty);
			}
			set
			{
				base.SetValue(InstancePanel.UsernameProperty, value);
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000085 RID: 133 RVA: 0x00004B1A File Offset: 0x00002D1A
		// (set) Token: 0x06000086 RID: 134 RVA: 0x00004B2C File Offset: 0x00002D2C
		public double UserID
		{
			get
			{
				return (double)base.GetValue(InstancePanel.UserIDProperty);
			}
			set
			{
				base.SetValue(InstancePanel.UserIDProperty, value);
				this.UpdateThumbnail();
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00004B45 File Offset: 0x00002D45
		// (set) Token: 0x06000088 RID: 136 RVA: 0x00004B57 File Offset: 0x00002D57
		public int ProcessID
		{
			get
			{
				return (int)base.GetValue(InstancePanel.ProcessIDProperty);
			}
			set
			{
				base.SetValue(InstancePanel.ProcessIDProperty, value);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000089 RID: 137 RVA: 0x00004B6A File Offset: 0x00002D6A
		// (set) Token: 0x0600008A RID: 138 RVA: 0x00004B7C File Offset: 0x00002D7C
		public string Script
		{
			get
			{
				return (string)base.GetValue(InstancePanel.ScriptProperty);
			}
			set
			{
				base.SetValue(InstancePanel.ScriptProperty, value);
			}
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00004B8A File Offset: 0x00002D8A
		public InstancePanel()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600008C RID: 140 RVA: 0x00004B98 File Offset: 0x00002D98
		private async void UpdateThumbnail()
		{
			Console.WriteLine("Yes");
			using (HttpClient client = new HttpClient())
			{
				try
				{
					ThumbnailResponse thumbnailResponse = JsonConvert.DeserializeObject<ThumbnailResponse>(await (await client.GetAsync("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=1&size=48x48&format=Png&isCircular=true")).Content.ReadAsStringAsync());
					BitmapImage bitmapImage = new BitmapImage();
					bitmapImage.BeginInit();
					bitmapImage.UriSource = new Uri(thumbnailResponse.Data[0].imageUrl, UriKind.Absolute);
					bitmapImage.EndInit();
					this.PlayerIcon.Background = new ImageBrush
					{
						ImageSource = bitmapImage
					};
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Thumbnail Grab Error");
				}
				finally
				{
					client.Dispose();
				}
			}
			HttpClient client = null;
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00004BCF File Offset: 0x00002DCF
		private void ExecuteButton_Click(object sender, RoutedEventArgs e)
		{
			Roblox.ExecuteSpecific(new int[] { this.ProcessID }, this.Script);
		}

		// Token: 0x0400008D RID: 141
		public static readonly DependencyProperty UsernameProperty = DependencyProperty.Register("Username", typeof(string), typeof(InstancePanel), new PropertyMetadata("Username"));

		// Token: 0x0400008E RID: 142
		public static readonly DependencyProperty UserIDProperty = DependencyProperty.Register("UserID", typeof(double), typeof(InstancePanel), new PropertyMetadata(0.0));

		// Token: 0x0400008F RID: 143
		public static readonly DependencyProperty ProcessIDProperty = DependencyProperty.Register("ProcessID", typeof(int), typeof(InstancePanel), new PropertyMetadata(0));

		// Token: 0x04000090 RID: 144
		public static readonly DependencyProperty ScriptProperty = DependencyProperty.Register("Script", typeof(string), typeof(InstancePanel), new PropertyMetadata("print('Not Implemented');"));
	}
}
