﻿using System;
using System.Collections.Generic;

namespace Wave.Classes.WebSockets
{
	// Token: 0x02000014 RID: 20
	internal class WebSocketCollection
	{
		// Token: 0x060000EB RID: 235 RVA: 0x000061F0 File Offset: 0x000043F0
		public static WebSocket AddSocket(string name, int port)
		{
			WebSocket webSocket = new WebSocket(port);
			WebSocketCollection.Sockets.Add(name, webSocket);
			return webSocket;
		}

		// Token: 0x060000EC RID: 236 RVA: 0x00006214 File Offset: 0x00004414
		public static void RemoveSocket(string name)
		{
			WebSocket webSocket = WebSocketCollection.Sockets[name];
			if (webSocket != null)
			{
				webSocket.Dispose();
				WebSocketCollection.Sockets.Remove(name);
			}
		}

		// Token: 0x040000F9 RID: 249
		public static Dictionary<string, WebSocket> Sockets = new Dictionary<string, WebSocket>();
	}
}
