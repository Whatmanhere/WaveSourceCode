﻿using System;
using System.Collections.Generic;
using WebSocketSharp.Server;

namespace Wave.Classes.WebSockets
{
	// Token: 0x02000015 RID: 21
	internal class WebSocket : IDisposable
	{
		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000EF RID: 239 RVA: 0x00006256 File Offset: 0x00004456
		public int Port { get; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x0000625E File Offset: 0x0000445E
		public WebSocketServer Server { get; }

		// Token: 0x060000F1 RID: 241 RVA: 0x00006266 File Offset: 0x00004466
		public WebSocket(int port)
		{
			this.Port = port;
			this.Server = new WebSocketServer(string.Format("ws://localhost:{0}", port));
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x0000629B File Offset: 0x0000449B
		public void AddBehaviour<T>(string path) where T : WebSocketBehavior, new()
		{
			if (!this.Behaviours.Contains(path))
			{
				this.Behaviours.Add(path);
				this.Server.AddWebSocketService<T>(path);
			}
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x000062C3 File Offset: 0x000044C3
		public void RemoveBehaviour(string path)
		{
			if (this.Behaviours.Contains(path))
			{
				this.Server.RemoveWebSocketService(path);
				this.Behaviours.Remove(path);
			}
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x000062F0 File Offset: 0x000044F0
		public void Dispose()
		{
			foreach (string text in this.Behaviours)
			{
				this.RemoveBehaviour(text);
			}
			this.Server.Stop();
		}

		// Token: 0x040000FC RID: 252
		public List<string> Behaviours = new List<string>();
	}
}
