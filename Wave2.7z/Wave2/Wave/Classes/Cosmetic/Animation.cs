﻿using System;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Microsoft.CSharp.RuntimeBinder;

namespace Wave.Classes.Cosmetic
{
	// Token: 0x02000027 RID: 39
	internal class Animation
	{
		// Token: 0x0600013A RID: 314 RVA: 0x00006FB8 File Offset: 0x000051B8
		public static Storyboard Animate(params AnimationPropertyBase[] propertyBases)
		{
			Storyboard storyboard = new Storyboard();
			foreach (AnimationPropertyBase animationPropertyBase in propertyBases)
			{ }
			return storyboard;
				
		}

		// Token: 0x0200004E RID: 78
		internal class Presets
		{
		}
	}
}
