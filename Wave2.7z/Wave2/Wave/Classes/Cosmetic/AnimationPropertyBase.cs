﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media.Animation;
using Microsoft.CSharp.RuntimeBinder;

namespace Wave.Classes.Cosmetic
{
	// Token: 0x02000028 RID: 40
	internal class AnimationPropertyBase
	{
		// Token: 0x0600013C RID: 316 RVA: 0x000071B0 File Offset: 0x000053B0
		public AnimationPropertyBase(dynamic element)
		{
			this.Element = element;
		}

		// Token: 0x0600013D RID: 317 RVA: 0x000071E3 File Offset: 0x000053E3
		public AnimationPropertyBase(dynamic element, dynamic overrideElement)
		{
			this.Element = element;
			this.OverrideElement = overrideElement;
		}

		// Token: 0x0600013E RID: 318 RVA: 0x00007220 File Offset: 0x00005420
		public Timeline CreateTimeline()
		{
			Timeline timeline = null;
			object obj;
			if (!(this.Property is string))
			{
				if (AnimationPropertyBase.<>o__10.<>p__1 == null)
				{
					AnimationPropertyBase.<>o__10.<>p__1 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetMember(CSharpBinderFlags.None, "Name", typeof(AnimationPropertyBase), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
				}
				Func<CallSite, object, object> target = AnimationPropertyBase.<>o__10.<>p__1.Target;
				CallSite <>p__ = AnimationPropertyBase.<>o__10.<>p__1;
				if (AnimationPropertyBase.<>o__10.<>p__0 == null)
				{
					AnimationPropertyBase.<>o__10.<>p__0 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetMember(CSharpBinderFlags.None, "PropertyType", typeof(AnimationPropertyBase), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
				}
				obj = target(<>p__, AnimationPropertyBase.<>o__10.<>p__0.Target(AnimationPropertyBase.<>o__10.<>p__0, this.Property));
			}
			else
			{
				obj = this.Property;
			}
			string text = obj as string;
			if (text != null)
			{
				if (!(text == "Double"))
				{
					if (!(text == "Thickness"))
					{
						if (text.Contains("Color"))
						{
							timeline = new ColorAnimation();
						}
					}
					else
					{
						timeline = new ThicknessAnimation();
					}
				}
				else
				{
					timeline = new DoubleAnimation();
				}
			}
			if (AnimationPropertyBase.<>o__10.<>p__6 == null)
			{
				AnimationPropertyBase.<>o__10.<>p__6 = CallSite<Action<CallSite, PropertyInfo, Timeline, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "SetValue", null, typeof(AnimationPropertyBase), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Action<CallSite, PropertyInfo, Timeline, object> target2 = AnimationPropertyBase.<>o__10.<>p__6.Target;
			CallSite <>p__2 = AnimationPropertyBase.<>o__10.<>p__6;
			PropertyInfo property = timeline.GetType().GetProperty("From");
			Timeline timeline2 = timeline;
			object obj2;
			if (this.From != null)
			{
				obj2 = this.From;
			}
			else
			{
				if (AnimationPropertyBase.<>o__10.<>p__5 == null)
				{
					AnimationPropertyBase.<>o__10.<>p__5 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, "GetValue", null, typeof(AnimationPropertyBase), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				Func<CallSite, object, object, object> target3 = AnimationPropertyBase.<>o__10.<>p__5.Target;
				CallSite <>p__3 = AnimationPropertyBase.<>o__10.<>p__5;
				if (AnimationPropertyBase.<>o__10.<>p__4 == null)
				{
					AnimationPropertyBase.<>o__10.<>p__4 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, "GetProperty", null, typeof(AnimationPropertyBase), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				Func<CallSite, object, object, object> target4 = AnimationPropertyBase.<>o__10.<>p__4.Target;
				CallSite <>p__4 = AnimationPropertyBase.<>o__10.<>p__4;
				if (AnimationPropertyBase.<>o__10.<>p__3 == null)
				{
					AnimationPropertyBase.<>o__10.<>p__3 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, "GetType", null, typeof(AnimationPropertyBase), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
				}
				object obj3 = AnimationPropertyBase.<>o__10.<>p__3.Target(AnimationPropertyBase.<>o__10.<>p__3, this.Element);
				object obj4;
				if (!(this.Property is string))
				{
					if (AnimationPropertyBase.<>o__10.<>p__2 == null)
					{
						AnimationPropertyBase.<>o__10.<>p__2 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetMember(CSharpBinderFlags.None, "Name", typeof(AnimationPropertyBase), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
					}
					obj4 = AnimationPropertyBase.<>o__10.<>p__2.Target(AnimationPropertyBase.<>o__10.<>p__2, this.Property);
				}
				else
				{
					obj4 = this.Property;
				}
				obj2 = target3(<>p__3, target4(<>p__4, obj3, obj4), this.Element);
			}
			target2(<>p__2, property, timeline2, obj2);
			if (AnimationPropertyBase.<>o__10.<>p__8 == null)
			{
				AnimationPropertyBase.<>o__10.<>p__8 = CallSite<Action<CallSite, PropertyInfo, Timeline, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "SetValue", null, typeof(AnimationPropertyBase), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Action<CallSite, PropertyInfo, Timeline, object> target5 = AnimationPropertyBase.<>o__10.<>p__8.Target;
			CallSite <>p__5 = AnimationPropertyBase.<>o__10.<>p__8;
			PropertyInfo property2 = timeline.GetType().GetProperty("To");
			Timeline timeline3 = timeline;
			object obj5;
			if (!(this.To is int))
			{
				obj5 = this.To;
			}
			else
			{
				if (AnimationPropertyBase.<>o__10.<>p__7 == null)
				{
					AnimationPropertyBase.<>o__10.<>p__7 = CallSite<Func<CallSite, Type, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, "ToDouble", null, typeof(AnimationPropertyBase), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				obj5 = AnimationPropertyBase.<>o__10.<>p__7.Target(AnimationPropertyBase.<>o__10.<>p__7, typeof(Convert), this.To);
			}
			target5(<>p__5, property2, timeline3, obj5);
			if (!this.DisableEasing)
			{
				timeline.GetType().GetProperty("EasingFunction").SetValue(timeline, this.EasingFunction);
			}
			timeline.Duration = this.Duration;
			return timeline;
		}

		// Token: 0x04000154 RID: 340
		[Dynamic]
		internal dynamic Element;

		// Token: 0x04000155 RID: 341
		[Dynamic]
		internal dynamic OverrideElement;

		// Token: 0x04000156 RID: 342
		[Dynamic]
		public dynamic Property;

		// Token: 0x04000157 RID: 343
		[Dynamic]
		public dynamic From;

		// Token: 0x04000158 RID: 344
		[Dynamic]
		public dynamic To;

		// Token: 0x04000159 RID: 345
		public bool DisableEasing;

		// Token: 0x0400015A RID: 346
		public IEasingFunction EasingFunction = new QuarticEase();

		// Token: 0x0400015B RID: 347
		public Duration Duration = TimeSpan.FromSeconds(0.4);
	}
}
