﻿using System;

namespace Wave.Classes.Implementations
{
	// Token: 0x0200001E RID: 30
	internal class Advertisement
	{
		// Token: 0x04000124 RID: 292
		public string localImageLink;

		// Token: 0x04000125 RID: 293
		public string redirectLink;
	}
}
