﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000021 RID: 33
	internal class Bloxstrap
	{
		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000112 RID: 274 RVA: 0x000068FC File Offset: 0x00004AFC
		public static BloxstrapSettings Instance
		{
			get
			{
				if (Bloxstrap.instance == null)
				{
					try
					{
						Bloxstrap.instance = JsonConvert.DeserializeObject<BloxstrapSettings>(File.ReadAllText(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Bloxstrap/Settings.json"));
					}
					catch
					{
						Bloxstrap.instance = new BloxstrapSettings();
					}
				}
				return Bloxstrap.instance;
			}
		}

		// Token: 0x0400012B RID: 299
		private static BloxstrapSettings instance;
	}
}
