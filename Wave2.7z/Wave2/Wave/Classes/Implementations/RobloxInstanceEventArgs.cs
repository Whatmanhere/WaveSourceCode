﻿using System;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000024 RID: 36
	internal class RobloxInstanceEventArgs : EventArgs
	{
		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000127 RID: 295 RVA: 0x00006DFD File Offset: 0x00004FFD
		// (set) Token: 0x06000128 RID: 296 RVA: 0x00006E05 File Offset: 0x00005005
		public int Id { get; set; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x06000129 RID: 297 RVA: 0x00006E0E File Offset: 0x0000500E
		// (set) Token: 0x0600012A RID: 298 RVA: 0x00006E16 File Offset: 0x00005016
		public bool AlreadyOpen { get; set; }

		// Token: 0x0600012B RID: 299 RVA: 0x00006E1F File Offset: 0x0000501F
		public RobloxInstanceEventArgs(int id, bool alreadyOpen)
		{
			this.Id = id;
			this.AlreadyOpen = alreadyOpen;
		}
	}
}
