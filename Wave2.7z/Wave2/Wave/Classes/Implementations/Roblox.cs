﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using SynapseXtra;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000023 RID: 35
	internal class Roblox
	{
		// Token: 0x14000009 RID: 9
		// (add) Token: 0x06000116 RID: 278 RVA: 0x00006984 File Offset: 0x00004B84
		// (remove) Token: 0x06000117 RID: 279 RVA: 0x000069B8 File Offset: 0x00004BB8
		public static event EventHandler<RobloxInstanceEventArgs> OnProcessFound;

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000118 RID: 280 RVA: 0x000069EC File Offset: 0x00004BEC
		// (remove) Token: 0x06000119 RID: 281 RVA: 0x00006A20 File Offset: 0x00004C20
		public static event EventHandler<RobloxInstanceEventArgs> OnProcessAdded;

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x0600011A RID: 282 RVA: 0x00006A54 File Offset: 0x00004C54
		// (remove) Token: 0x0600011B RID: 283 RVA: 0x00006A88 File Offset: 0x00004C88
		public static event EventHandler<RobloxInstanceEventArgs> OnProcessRemoved;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x0600011C RID: 284 RVA: 0x00006ABC File Offset: 0x00004CBC
		// (remove) Token: 0x0600011D RID: 285 RVA: 0x00006AF0 File Offset: 0x00004CF0
		public static event EventHandler<DetailedRobloxInstanceEventArgs> OnProcessInformationGained;

		// Token: 0x0600011E RID: 286 RVA: 0x00006B24 File Offset: 0x00004D24
		public static void Start()
		{
			foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
			{
				if (new RobloxInstance(process, false).IsInjected())
				{
					Roblox.AddProcess(process, true);
				}
			}
			Roblox.autoAttachTimer.Elapsed += async delegate(object sender, ElapsedEventArgs e)
			{
				foreach (Process process2 in Process.GetProcessesByName("RobloxPlayerBeta"))
				{
					if (!Roblox.IsProcessAdded(process2))
					{
						Roblox.AddProcess(process2, false);
						await Task.Delay(5000);
						Process.Start("Injector.exe", process2.Id.ToString());
						break;
					}
					process2 = null;
				}
			};
			Roblox.autoAttachTimer.Start();
			Roblox.deadProcessTimer.Elapsed += delegate(object sender, ElapsedEventArgs e)
			{
				for (int k = 0; k < Roblox.RobloxInstances.Count; k++)
				{
					RobloxInstance instance = Roblox.RobloxInstances[k];
					if (instance.RobloxProcess.HasExited || (instance.IsRunning && !instance.IsInjected()))
					{
						Application.Current.Dispatcher.Invoke(delegate
						{
							Roblox.RemoveProcess(instance.RobloxProcess);
						});
					}
				}
			};
			Roblox.deadProcessTimer.Start();
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00006BCC File Offset: 0x00004DCC
		public static async void AddProcess(Process robloxProcess, bool alreadyExisted = false)
		{
			RobloxInstance robloxInstance = new RobloxInstance(robloxProcess, true);
			Roblox.RobloxInstances.Add(robloxInstance);
			EventHandler<RobloxInstanceEventArgs> onProcessFound = Roblox.OnProcessFound;
			if (onProcessFound != null)
			{
				onProcessFound(robloxProcess, new RobloxInstanceEventArgs(robloxProcess.Id, alreadyExisted));
			}
			while (!robloxInstance.IsRunning)
			{
				await Task.Delay(250);
			}
			Roblox.ExecuteSpecific(new int[] { robloxProcess.Id }, Roblox.communicationInit);
			EventHandler<RobloxInstanceEventArgs> onProcessAdded = Roblox.OnProcessAdded;
			if (onProcessAdded != null)
			{
				onProcessAdded(robloxProcess, new RobloxInstanceEventArgs(robloxProcess.Id, alreadyExisted));
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x00006C0C File Offset: 0x00004E0C
		public static void RemoveProcess(Process robloxProcess)
		{
			for (int i = 0; i < Roblox.RobloxInstances.Count; i++)
			{
				RobloxInstance robloxInstance = Roblox.RobloxInstances[i];
				if (robloxInstance.RobloxProcess == robloxProcess)
				{
					Roblox.RobloxInstances.Remove(robloxInstance);
					break;
				}
			}
			EventHandler<RobloxInstanceEventArgs> onProcessRemoved = Roblox.OnProcessRemoved;
			if (onProcessRemoved == null)
			{
				return;
			}
			onProcessRemoved(null, new RobloxInstanceEventArgs(robloxProcess.Id, false));
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00006C70 File Offset: 0x00004E70
		public static bool IsProcessAdded(Process robloxProcess)
		{
			for (int i = 0; i < Roblox.RobloxInstances.Count; i++)
			{
				if (Roblox.RobloxInstances[i].RobloxProcess.Id == robloxProcess.Id)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00006CB4 File Offset: 0x00004EB4
		public static void ExecuteSpecific(int[] processIds, string script)
		{
			for (int i = 0; i < Roblox.RobloxInstances.Count; i++)
			{
				RobloxInstance robloxInstance = Roblox.RobloxInstances[i];
				if (processIds.Contains(robloxInstance.ProcessId) && robloxInstance.IsInjected())
				{
					robloxInstance.ExecuteScript(script);
				}
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00006D00 File Offset: 0x00004F00
		public static void ExecuteAll(string script)
		{
			for (int i = 0; i < Roblox.RobloxInstances.Count; i++)
			{
				RobloxInstance robloxInstance = Roblox.RobloxInstances[i];
				if (robloxInstance.IsInjected())
				{
					robloxInstance.ExecuteScript(script);
				}
			}
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00006D40 File Offset: 0x00004F40
		public static void GainProcessInformation(ClientInformation clientInfo)
		{
			EventHandler<DetailedRobloxInstanceEventArgs> onProcessInformationGained = Roblox.OnProcessInformationGained;
			if (onProcessInformationGained == null)
			{
				return;
			}
			onProcessInformationGained(null, new DetailedRobloxInstanceEventArgs
			{
				Username = clientInfo.Username,
				UserId = clientInfo.UserId,
				ProcessId = clientInfo.ProcessId,
				JobId = clientInfo.JobId
			});
		}

		// Token: 0x04000142 RID: 322
		public static List<RobloxInstance> RobloxInstances = new List<RobloxInstance>();

		// Token: 0x04000147 RID: 327
		private static readonly Timer autoAttachTimer = new Timer(2500.0);

		// Token: 0x04000148 RID: 328
		private static readonly Timer deadProcessTimer = new Timer(2500.0);

		// Token: 0x04000149 RID: 329
		private static readonly string communicationInit = new StreamReader(Application.GetResourceStream(new Uri("Assets\\Scripts\\Communicator.lua", UriKind.Relative)).Stream).ReadToEnd();
	}
}
