﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Azure.AI.OpenAI;
using Wave.Classes.Passive;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000020 RID: 32
	internal class AIChat
	{
		// Token: 0x0600010F RID: 271 RVA: 0x000067D8 File Offset: 0x000049D8
		public AIChat()
		{
			this.apiClient = new OpenAIClient(this.apiKey);
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(executingAssembly.GetManifestResourceNames().Single((string str) => str.EndsWith("AIContext.txt"))))
			{
				using (StreamReader streamReader = new StreamReader(manifestResourceStream))
				{
					this.aiContext = streamReader.ReadToEnd();
				}
			}
		}

		// Token: 0x06000110 RID: 272 RVA: 0x0000688C File Offset: 0x00004A8C
		public async Task<string> SendNewMessage(string message, string currentTab = null)
		{
			ChatCompletionsOptions chatCompletionsOptions = new ChatCompletionsOptions
			{
				DeploymentName = "gpt-3.5-turbo-1106",
				Messages = 
				{
					new ChatRequestSystemMessage(this.aiContext)
				}
			};
			this.conversationHistory.Add(new ChatRequestUserMessage(message));
			for (int i = 0; i < this.conversationHistory.Count; i++)
			{
				if (i == this.conversationHistory.Count - 1 || Settings.Instance.UseConversationHistory)
				{
					if (i == this.conversationHistory.Count - 1 && currentTab != null)
					{
						chatCompletionsOptions.Messages.Add(new ChatRequestSystemMessage("The user's currently selected tab content is below:\n\n```lua\n" + currentTab + "\n```"));
					}
					chatCompletionsOptions.Messages.Add(this.conversationHistory[i]);
				}
			}
			string content = (await this.apiClient.GetChatCompletionsAsync(chatCompletionsOptions, default(CancellationToken))).Value.Choices[0].Message.Content;
			this.conversationHistory.Add(new ChatRequestAssistantMessage(content));
			return content;
		}

		// Token: 0x06000111 RID: 273 RVA: 0x000068DF File Offset: 0x00004ADF
		public void ClearConversationHistory()
		{
			this.conversationHistory.RemoveRange(1, this.conversationHistory.Count - 1);
		}

		// Token: 0x04000127 RID: 295
		private readonly OpenAIClient apiClient;

		// Token: 0x04000128 RID: 296
		private readonly string apiKey = "";

		// Token: 0x04000129 RID: 297
		private readonly List<ChatRequestMessage> conversationHistory = new List<ChatRequestMessage>();

		// Token: 0x0400012A RID: 298
		private readonly string aiContext;
	}
}
