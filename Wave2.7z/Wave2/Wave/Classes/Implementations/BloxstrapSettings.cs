﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000022 RID: 34
	internal class BloxstrapSettings
	{
		// Token: 0x06000115 RID: 277 RVA: 0x00006964 File Offset: 0x00004B64
		public void Save()
		{
			File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Bloxstrap/Settings.json", JsonConvert.SerializeObject(this, Formatting.Indented));
		}

		// Token: 0x0400012C RID: 300
		public int BootstrapperStyle;

		// Token: 0x0400012D RID: 301
		public int BootstrapperIcon;

		// Token: 0x0400012E RID: 302
		public string BootstrapperTitle;

		// Token: 0x0400012F RID: 303
		public string BootstrapperIconCustomLocation;

		// Token: 0x04000130 RID: 304
		public int Theme;

		// Token: 0x04000131 RID: 305
		public bool CheckForUpdates;

		// Token: 0x04000132 RID: 306
		public bool CreateDesktopIcon;

		// Token: 0x04000133 RID: 307
		public bool MultiInstanceLaunching;

		// Token: 0x04000134 RID: 308
		public bool OhHeyYouFoundMe;

		// Token: 0x04000135 RID: 309
		public string Channel;

		// Token: 0x04000136 RID: 310
		public int ChannelChangeMode;

		// Token: 0x04000137 RID: 311
		public bool EnableActivityTracking;

		// Token: 0x04000138 RID: 312
		public bool UseDiscordRichPresence;

		// Token: 0x04000139 RID: 313
		public bool HideRPCButtons;

		// Token: 0x0400013A RID: 314
		public bool ShowServerDetails;

		// Token: 0x0400013B RID: 315
		public bool UseOldDeathSound;

		// Token: 0x0400013C RID: 316
		public bool UseOldCharacterSounds;

		// Token: 0x0400013D RID: 317
		public bool UseDisableAppPatch;

		// Token: 0x0400013E RID: 318
		public bool UseOldAvatarBackground;

		// Token: 0x0400013F RID: 319
		public int CursorType;

		// Token: 0x04000140 RID: 320
		public int EmojiType;

		// Token: 0x04000141 RID: 321
		public bool DisableFullscreenOptimizations;
	}
}
