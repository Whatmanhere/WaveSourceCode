﻿using System;

namespace Wave.Classes.Implementations
{
	// Token: 0x0200001F RID: 31
	internal class Advertisements
	{
		// Token: 0x0600010C RID: 268 RVA: 0x00006726 File Offset: 0x00004926
		public static Advertisement GetAdvertisement()
		{
			return Advertisements.ads[new Random().Next(Advertisements.ads.Length)];
		}

		// Token: 0x04000126 RID: 294
		private static readonly Advertisement[] ads = new Advertisement[]
		{
			new Advertisement
			{
				localImageLink = "/Assets/Images/Ads/WavePremiumAd.png",
				redirectLink = "https://getwave.gg"
			},
			new Advertisement
			{
				localImageLink = "/Assets/Images/Ads/LVAd.jpg",
				redirectLink = "https://publisher.linkvertise.com/ac/1138912"
			},
			new Advertisement
			{
				localImageLink = "/Assets/Images/Ads/WiiHubAd.png",
				redirectLink = "https://discord.gg/wiihub"
			},
			new Advertisement
			{
				localImageLink = "/Assets/Images/Ads/ArgonAd.png",
				redirectLink = "https://discord.gg/kMpdtwFh"
			}
		};
	}
}
