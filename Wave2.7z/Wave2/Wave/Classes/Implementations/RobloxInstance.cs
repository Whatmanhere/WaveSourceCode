﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000026 RID: 38
	internal class RobloxInstance
	{
		// Token: 0x06000135 RID: 309
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool WaitNamedPipe(string name, int timeout);

		// Token: 0x06000136 RID: 310 RVA: 0x00006E84 File Offset: 0x00005084
		public RobloxInstance(Process robloxProcess, bool awaitInjection = false)
		{
			if (robloxProcess == null || robloxProcess.ProcessName != "RobloxPlayerBeta")
			{
				MessageBox.Show("Attempted to register invalid process");
				return;
			}
			this.RobloxProcess = robloxProcess;
			this.ProcessId = robloxProcess.Id;
			this.PipeName = string.Format("Wave{0}", this.ProcessId);
			if (awaitInjection)
			{
				this.AwaitInjection();
			}
		}

		// Token: 0x06000137 RID: 311 RVA: 0x00006EFC File Offset: 0x000050FC
		public async void AwaitInjection()
		{
			while (!this.IsInjected())
			{
				await Task.Delay(250);
			}
			this.IsRunning = true;
		}

		// Token: 0x06000138 RID: 312 RVA: 0x00006F34 File Offset: 0x00005134
		public bool IsInjected()
		{
			bool flag = false;
			try
			{
				if (RobloxInstance.WaitNamedPipe("\\\\.\\pipe\\" + this.PipeName, 0))
				{
					flag = true;
				}
			}
			catch (Exception)
			{
				flag = false;
			}
			return flag;
		}

		// Token: 0x06000139 RID: 313 RVA: 0x00006F78 File Offset: 0x00005178
		public void ExecuteScript(string script)
		{
			if (!this.IsInjected())
			{
				return;
			}
			new Thread(delegate
			{
				try
				{
					using (NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", this.PipeName, PipeDirection.Out))
					{
						namedPipeClientStream.Connect();
						byte[] bytes = Encoding.UTF8.GetBytes(script);
						namedPipeClientStream.Write(bytes, 0, bytes.Length);
						namedPipeClientStream.Dispose();
					}
				}
				catch (IOException)
				{
					MessageBox.Show("Error occured connecting to the pipe.");
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}).Start();
		}

		// Token: 0x04000150 RID: 336
		public string PipeName = "Wave";

		// Token: 0x04000151 RID: 337
		public Process RobloxProcess;

		// Token: 0x04000152 RID: 338
		public int ProcessId;

		// Token: 0x04000153 RID: 339
		public bool IsRunning;
	}
}
