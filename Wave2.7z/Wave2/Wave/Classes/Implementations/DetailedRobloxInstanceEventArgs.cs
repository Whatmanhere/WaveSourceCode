﻿using System;

namespace Wave.Classes.Implementations
{
	// Token: 0x02000025 RID: 37
	internal class DetailedRobloxInstanceEventArgs : EventArgs
	{
		// Token: 0x1700002B RID: 43
		// (get) Token: 0x0600012C RID: 300 RVA: 0x00006E35 File Offset: 0x00005035
		// (set) Token: 0x0600012D RID: 301 RVA: 0x00006E3D File Offset: 0x0000503D
		public string Username { get; set; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600012E RID: 302 RVA: 0x00006E46 File Offset: 0x00005046
		// (set) Token: 0x0600012F RID: 303 RVA: 0x00006E4E File Offset: 0x0000504E
		public double UserId { get; set; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000130 RID: 304 RVA: 0x00006E57 File Offset: 0x00005057
		// (set) Token: 0x06000131 RID: 305 RVA: 0x00006E5F File Offset: 0x0000505F
		public int ProcessId { get; set; }

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000132 RID: 306 RVA: 0x00006E68 File Offset: 0x00005068
		// (set) Token: 0x06000133 RID: 307 RVA: 0x00006E70 File Offset: 0x00005070
		public string JobId { get; set; }
	}
}
