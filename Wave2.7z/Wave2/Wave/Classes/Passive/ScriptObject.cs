﻿using System;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace Wave.Classes.Passive
{
	// Token: 0x02000019 RID: 25
	public class ScriptObject
	{
		// Token: 0x060000FD RID: 253 RVA: 0x0000647F File Offset: 0x0000467F
		public void Correct()
		{
			Game game = this.game;
			if (game != null)
			{
				game.Correct();
			}
			Owner owner = this.owner;
			if (owner == null)
			{
				return;
			}
			owner.Correct();
		}

		// Token: 0x060000FE RID: 254 RVA: 0x000064A4 File Offset: 0x000046A4
		public async Task GetDetailedObject()
		{
			using (HttpClient client = new HttpClient())
			{
				foreach (JProperty jproperty in JToken.Parse(await (await client.GetAsync("https://scriptblox.com/api/script/" + this.slug)).Content.ReadAsStringAsync())["script"].Cast<JProperty>())
				{
					FieldInfo field = base.GetType().GetField(jproperty.Name);
					if (field != null)
					{
						field.SetValue(this, jproperty.Value.ToObject(field.FieldType));
					}
				}
			}
			HttpClient client = null;
		}

		// Token: 0x060000FF RID: 255 RVA: 0x000064E8 File Offset: 0x000046E8
		public async Task<string> GetScript()
		{
			if (this.script == null)
			{
				await this.GetDetailedObject();
			}
			return this.script;
		}

		// Token: 0x04000107 RID: 263
		public string title;

		// Token: 0x04000108 RID: 264
		public string features;

		// Token: 0x04000109 RID: 265
		public string script;

		// Token: 0x0400010A RID: 266
		public string slug;

		// Token: 0x0400010B RID: 267
		public DateTime createdAt;

		// Token: 0x0400010C RID: 268
		public DateTime updatedAt;

		// Token: 0x0400010D RID: 269
		public bool verified;

		// Token: 0x0400010E RID: 270
		public bool key;

		// Token: 0x0400010F RID: 271
		public bool isUniversal;

		// Token: 0x04000110 RID: 272
		public bool isPatched;

		// Token: 0x04000111 RID: 273
		public int views;

		// Token: 0x04000112 RID: 274
		public int likeCount;

		// Token: 0x04000113 RID: 275
		public int dislikeCount;

		// Token: 0x04000114 RID: 276
		public Game game;

		// Token: 0x04000115 RID: 277
		public Owner owner;
	}
}
