﻿using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace Wave.Classes.Passive
{
	// Token: 0x0200001A RID: 26
	internal class Settings
	{
		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000100 RID: 256 RVA: 0x0000652C File Offset: 0x0000472C
		public static SettingsInstance Instance
		{
			get
			{
				if (Settings.instance == null)
				{
					try
					{
						Settings.instance = JsonConvert.DeserializeObject<SettingsInstance>(File.ReadAllText("data/settings.json"));
					}
					catch
					{
						Settings.instance = new SettingsInstance();
					}
					finally
					{
						if (Settings.RandomNames.Contains(Settings.instance.AIUsername))
						{
							Settings.instance.AIUsername = Settings.RandomNames.GetRandomItem();
						}
					}
				}
				return Settings.instance;
			}
		}

		// Token: 0x04000116 RID: 278
		public static string[] RandomNames = new string[] { "Zendaya", "Ryan Reynolds", "Elon Musk", "Queen Liz", "Will Smith", "Johnny Knoxville" };

		// Token: 0x04000117 RID: 279
		private static SettingsInstance instance = null;
	}
}
