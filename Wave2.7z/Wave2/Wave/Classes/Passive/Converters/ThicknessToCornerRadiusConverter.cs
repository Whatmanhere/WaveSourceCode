﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Wave.Classes.Passive.Converters
{
	// Token: 0x0200001D RID: 29
	[ValueConversion(typeof(Thickness), typeof(CornerRadius))]
	public class ThicknessToCornerRadiusConverter : IValueConverter
	{
		// Token: 0x06000108 RID: 264 RVA: 0x000066A0 File Offset: 0x000048A0
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			Thickness thickness = (Thickness)value;
			return new CornerRadius(thickness.Left, thickness.Top, thickness.Right, thickness.Bottom);
		}

		// Token: 0x06000109 RID: 265 RVA: 0x000066DC File Offset: 0x000048DC
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			CornerRadius cornerRadius = (CornerRadius)value;
			return new Thickness(cornerRadius.TopLeft, cornerRadius.TopRight, cornerRadius.BottomRight, cornerRadius.BottomLeft);
		}
	}
}
