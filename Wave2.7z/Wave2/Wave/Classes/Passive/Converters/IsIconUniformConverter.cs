﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Wave.Classes.Passive.Converters
{
	// Token: 0x0200001C RID: 28
	[ValueConversion(typeof(bool), typeof(Stretch))]
	public class IsIconUniformConverter : IValueConverter
	{
		// Token: 0x06000105 RID: 261 RVA: 0x0000667C File Offset: 0x0000487C
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return ((bool)value) ? Stretch.Uniform : Stretch.Fill;
		}

		// Token: 0x06000106 RID: 262 RVA: 0x0000668F File Offset: 0x0000488F
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
