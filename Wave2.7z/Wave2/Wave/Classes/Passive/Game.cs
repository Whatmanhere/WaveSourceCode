﻿using System;

namespace Wave.Classes.Passive
{
	// Token: 0x02000017 RID: 23
	public class Game
	{
		// Token: 0x060000F9 RID: 249 RVA: 0x0000641B File Offset: 0x0000461B
		public void Correct()
		{
			if (this.imageUrl.StartsWith("/images/"))
			{
				this.imageUrl = "https://scriptblox.com" + this.imageUrl;
			}
		}

		// Token: 0x040000FD RID: 253
		public string gameId;

		// Token: 0x040000FE RID: 254
		public string name;

		// Token: 0x040000FF RID: 255
		public string imageUrl;
	}
}
