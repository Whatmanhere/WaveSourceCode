﻿using System;

namespace Wave.Classes.Passive
{
	// Token: 0x02000018 RID: 24
	public class Owner
	{
		// Token: 0x060000FB RID: 251 RVA: 0x0000644D File Offset: 0x0000464D
		public void Correct()
		{
			if (this.profilePicture.StartsWith("/images/"))
			{
				this.profilePicture = "https://scriptblox.com" + this.profilePicture;
			}
		}

		// Token: 0x04000100 RID: 256
		public string username;

		// Token: 0x04000101 RID: 257
		public string profilePicture;

		// Token: 0x04000102 RID: 258
		public string role;

		// Token: 0x04000103 RID: 259
		public string lastActive;

		// Token: 0x04000104 RID: 260
		public DateTime createdAt;

		// Token: 0x04000105 RID: 261
		public bool verified;

		// Token: 0x04000106 RID: 262
		public bool isBanned;
	}
}
