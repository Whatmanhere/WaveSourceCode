﻿using System;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Wave.Classes.Passive
{
	// Token: 0x0200001B RID: 27
	internal class SettingsInstance
	{
		// Token: 0x06000103 RID: 259 RVA: 0x00006608 File Offset: 0x00004808
		public async void Save()
		{
			if (!this.isQueued)
			{
				this.isQueued = true;
				while (this.isQueued)
				{
					int num = 0;
					try
					{
						File.WriteAllText("data/settings.json", JsonConvert.SerializeObject(this, Formatting.Indented));
						this.isQueued = false;
					}
					catch
					{
						num = 1;
					}
					if (num == 1)
					{
						await Task.Delay(500);
					}
				}
			}
		}

		// Token: 0x04000118 RID: 280
		public bool AutoExecute = true;

		// Token: 0x04000119 RID: 281
		public bool MultiInstance;

		// Token: 0x0400011A RID: 282
		public bool SaveTabs;

		// Token: 0x0400011B RID: 283
		public bool TopMost;

		// Token: 0x0400011C RID: 284
		public int EditorRefreshRate = 60;

		// Token: 0x0400011D RID: 285
		public double EditorTextSize = 14.0;

		// Token: 0x0400011E RID: 286
		public bool ShowMinimap;

		// Token: 0x0400011F RID: 287
		public bool ShowInlayHints;

		// Token: 0x04000120 RID: 288
		public string AIUsername = Settings.RandomNames.GetRandomItem();

		// Token: 0x04000121 RID: 289
		public bool UseConversationHistory = true;

		// Token: 0x04000122 RID: 290
		public bool AppendCurrentScript;

		// Token: 0x04000123 RID: 291
		private bool isQueued;
	}
}
