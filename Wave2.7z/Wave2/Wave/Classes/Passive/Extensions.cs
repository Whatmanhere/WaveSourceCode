﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Wave.Classes.Passive
{
	// Token: 0x02000016 RID: 22
	internal static class Extensions
	{
		// Token: 0x060000F5 RID: 245 RVA: 0x00006350 File Offset: 0x00004550
		internal static DependencyObject FindChild(this DependencyObject parent, string childName, Type childType)
		{
			DependencyObject dependencyObject = null;
			if (parent != null)
			{
				int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
				for (int i = 0; i < childrenCount; i++)
				{
					DependencyObject child = VisualTreeHelper.GetChild(parent, i);
					if (child.GetType() != childType)
					{
						dependencyObject = child.FindChild(childName, childType);
						if (dependencyObject != null)
						{
							break;
						}
					}
					else
					{
						if (string.IsNullOrEmpty(childName))
						{
							dependencyObject = child;
							break;
						}
						FrameworkElement frameworkElement = child as FrameworkElement;
						if (frameworkElement != null && frameworkElement.Name == childName)
						{
							dependencyObject = child;
							break;
						}
					}
				}
			}
			return dependencyObject;
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x000063C8 File Offset: 0x000045C8
		internal static void SetUriSource(this Image image, string link)
		{
			BitmapImage bitmapImage = new BitmapImage();
			bitmapImage.BeginInit();
			bitmapImage.UriSource = new Uri(link, UriKind.Absolute);
			bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
			bitmapImage.EndInit();
			image.Source = bitmapImage;
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x00006402 File Offset: 0x00004602
		internal static string GetRandomItem(this string[] strings)
		{
			return strings[new Random().Next(strings.Length)];
		}
	}
}
