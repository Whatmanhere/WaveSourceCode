﻿using System;
using System.Windows;
using Newtonsoft.Json;
using Wave.Classes.Implementations;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace SynapseXtra
{
	// Token: 0x02000003 RID: 3
	public class ClientInformationBehavior : WebSocketBehavior
	{
		// Token: 0x06000008 RID: 8 RVA: 0x000020C8 File Offset: 0x000002C8
		protected override void OnMessage(MessageEventArgs e)
		{
			try
			{
				Roblox.GainProcessInformation(JsonConvert.DeserializeObject<ClientInformation>(e.Data));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.InnerException.Message);
			}
		}
	}
}
