﻿using System;

namespace SynapseXtra
{
	// Token: 0x02000004 RID: 4
	public class ClientInformation
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000009 RID: 9 RVA: 0x0000210C File Offset: 0x0000030C
		// (set) Token: 0x0600000A RID: 10 RVA: 0x00002114 File Offset: 0x00000314
		public string Username { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600000B RID: 11 RVA: 0x0000211D File Offset: 0x0000031D
		// (set) Token: 0x0600000C RID: 12 RVA: 0x00002125 File Offset: 0x00000325
		public double UserId { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600000D RID: 13 RVA: 0x0000212E File Offset: 0x0000032E
		// (set) Token: 0x0600000E RID: 14 RVA: 0x00002136 File Offset: 0x00000336
		public int ProcessId { get; set; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600000F RID: 15 RVA: 0x0000213F File Offset: 0x0000033F
		// (set) Token: 0x06000010 RID: 16 RVA: 0x00002147 File Offset: 0x00000347
		public string JobId { get; set; }
	}
}
